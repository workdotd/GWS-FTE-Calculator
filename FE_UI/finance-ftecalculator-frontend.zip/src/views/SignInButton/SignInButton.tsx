import styles from "../../styles/signInButton.module.scss";
import { EmeraldButton } from "@emerald-react/button";
import { EmeraldButtonSize } from "@emerald/nxcore";

interface SignInButtonProps {
  label: string;
  clickEvent?: () => void;
}

export const SignInButton: React.FC<SignInButtonProps> = ({
  label,
  clickEvent,
}) => {
  return (
    <div>
      <EmeraldButton
        label={label}
        onClick={clickEvent}
        size={EmeraldButtonSize.Medium}
        classes={styles.emeraldButton}
      />
    </div>
  );
};
