import { Brand } from "../Brand/Brand";
import { SignInButton } from "../SignInButton/SignInButton";
import style from "../../styles/signInDialog.module.scss";
import React from "react";
import { useAuth } from "react-oidc-context";

export const SignInDialog: React.FC = () => {
  const auth = useAuth();

  const handleLogin = () => {
    auth.signinRedirect().catch((error) => {
      console.log(error);
    });
  };

  return (
    <div className={style.signInDialog}>
      <Brand />
      <div className={style.ssoSection}>
        <h2 className={style.signInTitle}>Sign in</h2>
        <SignInButton label="Sign in with SSO" clickEvent={handleLogin} />
      </div>
    </div>
  );
};
