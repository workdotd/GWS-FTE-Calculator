import { useNavigate } from "react-router-dom";
import { useAuth } from "react-oidc-context";

export const CallBack: React.FC = () => {
  const navigate = useNavigate();

  const auth = useAuth();

  if (auth.isAuthenticated) {
    navigate("/home");
    return <></>;
  } else if (auth.isLoading) {
    return (
      <div
        style={{
          width: "100vw",
          height: "calc(100vh - 8.7rem)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <h1>
          <center>Redirecting...</center>
        </h1>
      </div>
    );
  } else {
    navigate("/");
    return <></>;
  }
};
