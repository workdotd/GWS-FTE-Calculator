import { Options } from "./Options";

// For AMERICAS
export const ContractValuesAMS: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">50M of Managed Spend", value: ">50M of Managed Spend" },
  { label: ">20<50M of Managed Spend", value: ">20<50M of Managed Spend" },
  { label: "<20M of Managed Spend", value: "<20M of Managed Spend" },
];

export const GrowthValuesAMS: Options[] = [
  { label: "None", selected: true, value: "None" },
  {
    label: ">15M opportunity for growth",
    value: ">15M opportunity for growth",
  },
  {
    label: "5M-15M opportunity for growth",
    value: "5M-15M opportunity for growth",
  },
  { label: "<5M opportunity for growth", value: "<5M opportunity for growth" },
];

export const PerformanceValuesAMS: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">2.5M fees at risk", value: ">2.5M fees at risk" },
  { label: "1M-2.5M fees at risk", value: "1M-2.5M fees at risk" },
  { label: "<1M fees at risk", value: "<1M fees at risk" },
];

export const FMRolesAMS: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: "Finance Director", value: "Finance Director" },
  { label: "Sr. Finance Manager", value: "Sr. Finance Manager" },
  { label: "Finance Manager", value: "Finance Manager" },
];

// Fo EMEA
export const ContractValuesEMEA: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">50M of Managed Spend", value: ">50M of Managed Spend" },
  { label: ">20<50M of Managed Spend", value: ">20<50M of Managed Spend" },
  { label: "<20M of Managed Spend", value: "<20M of Managed Spend" },
];

export const GrowthValuesEMEA: Options[] = [
  { label: "None", selected: true, value: "None" },
  {
    label: ">15M opportunity for growth",
    value: ">15M opportunity for growth",
  },
  {
    label: "5M-15M opportunity for growth",
    value: "5M-15M opportunity for growth",
  },
  { label: "<5M opportunity for growth", value: "<5M opportunity for growth" },
];

export const PerformanceValuesEMEA: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">2.5M fees at risk", value: ">2.5M fees at risk" },
  { label: "1M-2.5M fees at risk", value: "1M-2.5M fees at risk" },
  { label: "<1M fees at risk", value: "<1M fees at risk" },
];

export const FMRolesEMEA: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: "Finance Director", value: "Finance Director" },
  { label: "Sr. Finance Manager", value: "Sr. Finance Manager" },
  { label: "Finance Manager", value: "Finance Manager" },
];

// For APAC
export const ContractValuesAPAC: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">40M of Managed Spend", value: ">40M of Managed Spend" },
  { label: ">15<40M of Managed Spend", value: ">15<40M of Managed Spend" },
  { label: "<15M of Managed Spend", value: "<15M of Managed Spend" },
];

export const GrowthValuesAPAC: Options[] = [
  { label: "None", selected: true, value: "None" },
  {
    label: ">12M opportunity for growth",
    value: ">12M opportunity for growth",
  },
  {
    label: "3M-12M opportunity for growth",
    value: "3M-12M opportunity for growth",
  },
  { label: "<3M opportunity for growth", value: "<3M opportunity for growth" },
];

export const PerformanceValuesAPAC: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: ">2M fees at risk", value: ">2M fees at risk" },
  { label: "0.75M-2M fees at risk", value: "0.75M-2M fees at risk" },
  { label: "<0.75M fees at risk", value: "<0.75M fees at risk" },
];

export const FMRolesAPAC: Options[] = [
  { label: "None", selected: true, value: "None" },
  { label: "Finance Director", value: "Finance Director" },
  { label: "Sr. Finance Manager", value: "Sr. Finance Manager" },
  { label: "Finance Manager", value: "Finance Manager" },
];
