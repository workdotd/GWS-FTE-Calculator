import { Options } from "./Options";

// Contract Structure Values
export const ContractStructureValues: Options[] = [
  { label: "GMP", selected: true, value: "GMP" },
  { label: "Cost Plus", value: "Cost Plus" },
  { label: "Fixed Price", value: "Fixed Price" },
  { label: "Other", value: "Other" },
];

export function getContractStructureValues(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return ContractStructureValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return ContractStructureValues;
  }
}

// Spend Ratio Values
export const SpendRatioValues: Options[] = [
  {
    label: "25% fixed; 75% variable",
    selected: true,
    value: "25% fixed; 75% variable",
  },
  { label: "50% fixed; 50% variable", value: "50% fixed; 50% variable" },
  { label: "75% fixed; 25% variable", value: "75% fixed; 25% variable" },
];

export function getSpendRatioValues(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return SpendRatioValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return SpendRatioValues;
  }
}

// PrincipalMA Values
export const PrincipalMAValues: Options[] = [
  {
    label: "Full Principal (immaterial agency spend)",
    selected: true,
    value: "Full Principal (immaterial agency spend)",
  },
  {
    label: "Full Managing Agent (immaterial principal spend)",
    value: "Full Managing Agent (immaterial principal spend)",
  },
  { label: "50% Principal; 50% MA", value: "50% Principal; 50% MA" },
  { label: "25% Principal; 75% MA", value: "25% Principal; 75% MA" },
  { label: "75% Principal; 25% MA", value: "75% Principal; 25% MA" },
];

export function getPrincipalMAValues(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return PrincipalMAValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return PrincipalMAValues;
  }
}

//  CRL Values
export const CRLValues: Options[] = [
  { label: "Country-level", selected: true, value: "Country-level" },
  { label: "Site-level", value: "Site-level" },
  { label: "Cost-center level", value: "Cost-center level" },
];

export function getCRLValues(selectedValue: string | undefined): Options[] {
  if (selectedValue) {
    return CRLValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return CRLValues;
  }
}

// Tech Stack Values
export const TechStackValues: Options[] = [
  {
    label: "Standard - Mybuy/JDE/PS",
    selected: true,
    value: "Standard - Mybuy/JDE/PS",
  },
  { label: "Full Iscala", value: "Full Iscala" },
  { label: "Full PS", value: "Full PS" },
  { label: "Non-standard", value: "Non-standard" },
];

export function getTechStackValues(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return TechStackValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return TechStackValues;
  }
}

// Automtion Values
export const AutomationValues: Options[] = [
  { label: "High", selected: true, value: "High" },
  { label: "Mid", value: "Mid" },
  { label: "Low", value: "Low" },
  { label: "None", value: "None" },
];

export function getAutomationValues(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return AutomationValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return AutomationValues;
  }
}

// Bank Values
export const BankValues: Options[] = [
  { label: "Dedicated", selected: true, value: "Dedicated" },
  { label: "Shared/Ded", value: "Shared/Ded" },
  { label: "Corporate", value: "Corporate" },
];

export function getBankValues(selectedValue: string | undefined): Options[] {
  if (selectedValue) {
    return BankValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return BankValues;
  }
}
