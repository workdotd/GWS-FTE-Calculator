import { ReactNode, useState } from "react";
import {
  ARAPType,
  CBREReportType,
  ClientReportType,
  ContractVariablesType,
  MyContext,
  MyContextType,
  RegionFDType,
  RegionFMType,
  ResponseMethodType,
} from "./FMContext";
import {
  GrowthValuesAPAC,
  ContractValuesAPAC,
  PerformanceValuesAPAC,
  GrowthValuesEMEA,
  ContractValuesEMEA,
  PerformanceValuesEMEA,
  GrowthValuesAMS,
  ContractValuesAMS,
  PerformanceValuesAMS,
  FMRolesAMS,
  FMRolesEMEA,
  FMRolesAPAC,
} from "../data/FMRole_GCPValues";
import {
  AmericasRoleLocations,
  ApacRoleLocations,
  EmeaRoleLocations,
  GlobalRoleLocations,
} from "../data/RoleLocations";

type MyProviderProps = {
  children: ReactNode;
};

export const MyProvider: React.FC<MyProviderProps> = ({ children }) => {
  const [ClientName, setClientName] = useState<string>("My Client");

  // ------------------------------------ FM Context -------------------------------------------------

  // Role of Different Regions
  const [AMrole, setAMRole] = useState<string>(FMRolesAMS[0].value);
  const [EMrole, setEMRole] = useState<string>(FMRolesEMEA[0].value);
  const [AProle, setAPRole] = useState<string>(FMRolesAPAC[0].value);

  // GCP of Americas
  const [AMGrowth, setAMGrowth] = useState<string>(GrowthValuesAMS[0].value);
  const [AMContract, setAMContract] = useState<string>(
    ContractValuesAMS[0].value
  );
  const [AMPerform, setAMPerform] = useState<string>(
    PerformanceValuesAMS[0].value
  );

  // GCP of Emea
  const [EMGrowth, setEMGrowth] = useState<string>(GrowthValuesEMEA[0].value);
  const [EMContract, setEMContract] = useState<string>(
    ContractValuesEMEA[0].value
  );
  const [EMPerform, setEMPerform] = useState<string>(
    PerformanceValuesEMEA[0].value
  );

  // GCP of Apac
  const [APGrowth, setAPGrowth] = useState<string>(GrowthValuesAPAC[0].value);
  const [APContract, setAPContract] = useState<string>(
    ContractValuesAPAC[0].value
  );
  const [APPerform, setAPPerform] = useState<string>(
    PerformanceValuesAPAC[0].value
  );

  // Location for different Regions
  const [AMLocation, setAMLocation] = useState<string>(
    AmericasRoleLocations[0].value
  );
  const [EMLocation, setEMLocation] = useState<string>(
    EmeaRoleLocations[0].value
  );
  const [APLocation, setAPLocation] = useState<string>(
    ApacRoleLocations[0].value
  );

  // Setting the values for each region
  const AmericasFM: RegionFMType = {
    Role: {
      value: AMrole,
      setValue: setAMRole,
    },
    Growth: {
      value: AMGrowth,
      setValue: setAMGrowth,
    },
    Contract: {
      value: AMContract,
      setValue: setAMContract,
    },
    Performance: {
      value: AMPerform,
      setValue: setAMPerform,
    },
    Location: {
      value: AMLocation,
      setValue: setAMLocation,
    },
  };

  const EmeaFM: RegionFMType = {
    Role: {
      value: EMrole,
      setValue: setEMRole,
    },
    Growth: {
      value: EMGrowth,
      setValue: setEMGrowth,
    },
    Contract: {
      value: EMContract,
      setValue: setEMContract,
    },
    Performance: {
      value: EMPerform,
      setValue: setEMPerform,
    },
    Location: {
      value: EMLocation,
      setValue: setEMLocation,
    },
  };

  const ApacFM: RegionFMType = {
    Role: {
      value: AProle,
      setValue: setAPRole,
    },
    Growth: {
      value: APGrowth,
      setValue: setAPGrowth,
    },
    Contract: {
      value: APContract,
      setValue: setAPContract,
    },
    Performance: {
      value: APPerform,
      setValue: setAPPerform,
    },
    Location: {
      value: APLocation,
      setValue: setAPLocation,
    },
  };

  // Global Assessment States
  const [Region, setRegion] = useState<Array<string>>([]);
  const [RoleRequirement, setRoleRequirement] = useState<string>("Yes");
  const [GlobalLocation, setGlobalLocation] = useState<string>(
    GlobalRoleLocations[0].value
  );
  const [GlobalRole, setGlobalRole] = useState<string>("No Role Recommended");
  const [GlobalSpend, setGlobalSpend] = useState<string>(
    "Below 50M Managed Spend"
  );

  // -------------------------------------------- FD Context -------------------------------------------------------------------------------

  const [FDRegion, setFDRegion] = useState<string>("AMERICAS");

  // >------------------ AMERICAS ------------------------<
  const [AMSpend, setAMSpend] = useState<number>(0);
  // Look into the possible logic
  const [AMCountrySites, setAMCountrySites] = useState<Map<string, number>>(
    new Map()
  );

  const [AMStructure, setAMStructure] = useState<string>("GMP");
  const [AMSpendRatio, setAMSpendRatio] = useState<string>(
    "25% fixed; 75% variable"
  );
  const [AMPrincipal, setAMPrincipal] = useState<string>(
    "Full Principal (immaterial agency spend)"
  );
  const [AMCRL, setAMCRL] = useState<string>("Country-level");
  const [AMTechStack, setAMTechStack] = useState<string>(
    "Standard - Mybuy/JDE/PS"
  );
  const [AMAutomationAdj, setAMAutomationAdj] = useState<string>("High");
  const [AMBankAccount, setAMBankAccount] = useState<string>("Dedicated");

  const AmericasContractVariables: ContractVariablesType = {
    Structure: {
      value: AMStructure,
      setValue: setAMStructure,
    },
    SpendRatio: {
      value: AMSpendRatio,
      setValue: setAMSpendRatio,
    },
    Principal: {
      value: AMPrincipal,
      setValue: setAMPrincipal,
    },
    CRL: {
      value: AMCRL,
      setValue: setAMCRL,
    },
    TechStack: {
      value: AMTechStack,
      setValue: setAMTechStack,
    },
    AutomationAdj: {
      value: AMAutomationAdj,
      setValue: setAMAutomationAdj,
    },
    BankAccount: {
      value: AMBankAccount,
      setValue: setAMBankAccount,
    },
  };

  const [AMBilling, setAMBilling] = useState<string>("Monthly");
  const [AMFundRecon, setAMFundRecon] = useState<string>("Monthly");
  const [AMPayment, setAMPayment] = useState<string>("Monthly");

  const AmericasARAP: ARAPType = {
    Billing: {
      value: AMBilling,
      setValue: setAMBilling,
    },
    FundRecon: {
      value: AMFundRecon,
      setValue: setAMFundRecon,
    },
    Payment: {
      value: AMPayment,
      setValue: setAMPayment,
    },
  };

  const [AMOpenPOReview, setAMOpenPOReview] = useState<string>("Monthly");
  const [AMBalanceSheetRecon, setAMBalanceSheetRecon] =
    useState<string>("Monthly");
  const [AMMER, setAMMER] = useState<string>("Monthly");
  const [AMPTR, setAMPTR] = useState<string>("Monthly");
  const [AMPES, setAMPES] = useState<string>("Monthly");
  const [AMASR, setAMASR] = useState<string>("Monthly");
  const [AMMERAQ, setAMMERAQ] = useState<string>("Monthly");
  const [AMPRA, setAMPRA] = useState<string>("Monthly");
  const [AMOMBR, setAMOMBR] = useState<string>("Monthly");
  const [AMEA, setAMEA] = useState<string>("Monthly");

  const AmericasCBREReport: CBREReportType = {
    OpenPOReview: {
      value: AMOpenPOReview,
      setValue: setAMOpenPOReview,
    },
    BalanceSheetRecon: {
      value: AMBalanceSheetRecon,
      setValue: setAMBalanceSheetRecon,
    },
    MER: {
      value: AMMER,
      setValue: setAMMER,
    },
    PTR: {
      value: AMPTR,
      setValue: setAMPTR,
    },
    PES: {
      value: AMPES,
      setValue: setAMPES,
    },
    ASR: {
      value: AMASR,
      setValue: setAMASR,
    },
    MERAQ: {
      value: AMMERAQ,
      setValue: setAMMERAQ,
    },
    PRA: {
      value: AMPRA,
      setValue: setAMPRA,
    },
    MEA: {
      value: AMEA,
      setValue: setAMEA,
    },
    OMBR: {
      value: AMOMBR,
      setValue: setAMOMBR,
    },
  };

  const [AMMEA, setAMMEA] = useState<string>("Monthly");
  const [AMMOC, setAMMOC] = useState<string>("Monthly");
  const [AMCB, setAMCB] = useState<string>("Monthly");
  const [AMCF, setAMCF] = useState<string>("Monthly");
  const [AMCSR, setAMCSR] = useState<string>("Monthly");
  const [AMCFAS, setAMCFAS] = useState<string>("Monthly");
  const [AMCBAR, setAMCBAR] = useState<string>("Monthly");
  const [AMReportType, setAMReportType] = useState<string>("Standard Report");
  const [AMReport_Freq, setAMReport_Freq] = useState<string>("Monthly");

  const AmericasClientReport: ClientReportType = {
    MEA: {
      value: AMMEA,
      setValue: setAMMEA,
    },
    MOC: {
      value: AMMOC,
      setValue: setAMMOC,
    },
    CB: {
      value: AMCB,
      setValue: setAMCB,
    },
    CF: {
      value: AMCF,
      setValue: setAMCF,
    },
    CSR: {
      value: AMCSR,
      setValue: setAMCSR,
    },
    CFAS: {
      value: AMCFAS,
      setValue: setAMCFAS,
    },
    CBAR: {
      value: AMCBAR,
      setValue: setAMCBAR,
    },
    ReportType: {
      value: AMReportType,
      setValue: setAMReportType,
    },
    Report_Freq: {
      value: AMReport_Freq,
      setValue: setAMReport_Freq,
    },
  };

  const [AMDelivery, setAMDelivery] = useState<string>("On-site");

  const AmericasFD: RegionFDType = {
    Spend: {
      value: AMSpend,
      setValue: setAMSpend,
    },
    Country_Sites: {
      value: AMCountrySites,
      setValue: setAMCountrySites,
    },
    ContractVariables: AmericasContractVariables,
    ARAP: AmericasARAP,
    CBREReport: AmericasCBREReport,
    ClientReport: AmericasClientReport,
    DeliveryModel: {
      value: AMDelivery,
      setValue: setAMDelivery,
    },
  };

  // >------------------ EMEA ------------------------<
  const [EMSpend, setEMSpend] = useState<number>(0);
  const [EMCountrySites, setEMCountrySites] = useState<Map<string, number>>(
    new Map()
  );

  const [EMStructure, setEMStructure] = useState<string>("GMP");
  const [EMSpendRatio, setEMSpendRatio] = useState<string>(
    "25% fixed; 75% variable"
  );
  const [EMPrincipal, setEMPrincipal] = useState<string>(
    "Full Principal (immaterial agency spend)"
  );
  const [EMCRL, setEMCRL] = useState<string>("Country-level");
  const [EMTechStack, setEMTechStack] = useState<string>(
    "Standard - Mybuy/JDE/PS"
  );
  const [EMAutomationAdj, setEMAutomationAdj] = useState<string>("High");
  const [EMBankAccount, setEMBankAccount] = useState<string>("Dedicated");

  const EmeaContractVariables: ContractVariablesType = {
    Structure: {
      value: EMStructure,
      setValue: setEMStructure,
    },
    SpendRatio: {
      value: EMSpendRatio,
      setValue: setEMSpendRatio,
    },
    Principal: {
      value: EMPrincipal,
      setValue: setEMPrincipal,
    },
    CRL: {
      value: EMCRL,
      setValue: setEMCRL,
    },
    TechStack: {
      value: EMTechStack,
      setValue: setEMTechStack,
    },
    AutomationAdj: {
      value: EMAutomationAdj,
      setValue: setEMAutomationAdj,
    },
    BankAccount: {
      value: EMBankAccount,
      setValue: setEMBankAccount,
    },
  };

  const [EMBilling, setEMBilling] = useState<string>("Monthly");
  const [EMFundRecon, setEMFundRecon] = useState<string>("Monthly");
  const [EMPayment, setEMPayment] = useState<string>("Monthly");

  const EmeaARAP: ARAPType = {
    Billing: {
      value: EMBilling,
      setValue: setEMBilling,
    },
    FundRecon: {
      value: EMFundRecon,
      setValue: setEMFundRecon,
    },
    Payment: {
      value: EMPayment,
      setValue: setEMPayment,
    },
  };

  const [EMOpenPOReview, setEMOpenPOReview] = useState<string>("Monthly");
  const [EMBalanceSheetRecon, setEMBalanceSheetRecon] =
    useState<string>("Monthly");
  const [EMMER, setEMMER] = useState<string>("Monthly");
  const [EMPTR, setEMPTR] = useState<string>("Monthly");
  const [EMPES, setEMPES] = useState<string>("Monthly");
  const [EMASR, setEMASR] = useState<string>("Monthly");
  const [EMMERAQ, setEMMERAQ] = useState<string>("Monthly");
  const [EMPRA, setEMPRA] = useState<string>("Monthly");
  const [EMOMBR, setEMOMBR] = useState<string>("Monthly");
  const [EMEA, setEMEA] = useState<string>("Monthly");

  const EmeaCBREReport: CBREReportType = {
    OpenPOReview: {
      value: EMOpenPOReview,
      setValue: setEMOpenPOReview,
    },
    BalanceSheetRecon: {
      value: EMBalanceSheetRecon,
      setValue: setEMBalanceSheetRecon,
    },
    MER: {
      value: EMMER,
      setValue: setEMMER,
    },
    PTR: {
      value: EMPTR,
      setValue: setEMPTR,
    },
    PES: {
      value: EMPES,
      setValue: setEMPES,
    },
    ASR: {
      value: EMASR,
      setValue: setEMASR,
    },
    MERAQ: {
      value: EMMERAQ,
      setValue: setEMMERAQ,
    },
    PRA: {
      value: EMPRA,
      setValue: setEMPRA,
    },
    MEA: {
      value: EMEA,
      setValue: setEMEA,
    },
    OMBR: {
      value: EMOMBR,
      setValue: setEMOMBR,
    },
  };

  const [EMMEA, setEMMEA] = useState<string>("Monthly");
  const [EMMOC, setEMMOC] = useState<string>("Monthly");
  const [EMCB, setEMCB] = useState<string>("Monthly");
  const [EMCF, setEMCF] = useState<string>("Monthly");
  const [EMCSR, setEMCSR] = useState<string>("Monthly");
  const [EMCFAS, setEMCFAS] = useState<string>("Monthly");
  const [EMCBAR, setEMCBAR] = useState<string>("Monthly");
  const [EMReportType, setEMReportType] = useState<string>("Standard Report");
  const [EMReport_Freq, setEMReport_Freq] = useState<string>("Monthly");

  const EmeaClientReport: ClientReportType = {
    MEA: {
      value: EMMEA,
      setValue: setEMMEA,
    },
    MOC: {
      value: EMMOC,
      setValue: setEMMOC,
    },
    CB: {
      value: EMCB,
      setValue: setEMCB,
    },
    CF: {
      value: EMCF,
      setValue: setEMCF,
    },
    CSR: {
      value: EMCSR,
      setValue: setEMCSR,
    },
    CFAS: {
      value: EMCFAS,
      setValue: setEMCFAS,
    },
    CBAR: {
      value: EMCBAR,
      setValue: setEMCBAR,
    },
    ReportType: {
      value: EMReportType,
      setValue: setEMReportType,
    },
    Report_Freq: {
      value: EMReport_Freq,
      setValue: setEMReport_Freq,
    },
  };

  const [EMDelivery, setEMDelivery] = useState<string>("On-site");

  const EmeaFD: RegionFDType = {
    Spend: {
      value: EMSpend,
      setValue: setEMSpend,
    },
    Country_Sites: {
      value: EMCountrySites,
      setValue: setEMCountrySites,
    },
    ContractVariables: EmeaContractVariables,
    ARAP: EmeaARAP,
    CBREReport: EmeaCBREReport,
    ClientReport: EmeaClientReport,
    DeliveryModel: {
      value: EMDelivery,
      setValue: setEMDelivery,
    },
  };

  // >------------------ APAC ------------------------<

  const [APSpend, setAPSpend] = useState<number>(0);
  const [APCountrySites, setAPCountrySites] = useState<Map<string, number>>(
    new Map()
  );

  const [APBilling, setAPBilling] = useState<string>("Monthly");
  const [APFundRecon, setAPFundRecon] = useState<string>("Monthly");
  const [APPayment, setAPPayment] = useState<string>("Monthly");

  const ApacARAP: ARAPType = {
    Billing: {
      value: APBilling,
      setValue: setAPBilling,
    },
    FundRecon: {
      value: APFundRecon,
      setValue: setAPFundRecon,
    },
    Payment: {
      value: APPayment,
      setValue: setAPPayment,
    },
  };

  const [APOpenPOReview, setAPOpenPOReview] = useState<string>("Monthly");
  const [APBalanceSheetRecon, setAPBalanceSheetRecon] =
    useState<string>("Monthly");
  const [APMER, setAPMER] = useState<string>("Monthly");
  const [APPTR, setAPPTR] = useState<string>("Monthly");
  const [APPES, setAPPES] = useState<string>("Monthly");
  const [APASR, setAPASR] = useState<string>("Monthly");
  const [APMERAQ, setAPMERAQ] = useState<string>("Monthly");
  const [APPRA, setAPPRA] = useState<string>("Monthly");
  const [APOMBR, setAPOMBR] = useState<string>("Monthly");
  const [APEA, setAPEA] = useState<string>("Monthly");

  const ApacCBREReport: CBREReportType = {
    OpenPOReview: {
      value: APOpenPOReview,
      setValue: setAPOpenPOReview,
    },
    BalanceSheetRecon: {
      value: APBalanceSheetRecon,
      setValue: setAPBalanceSheetRecon,
    },
    MER: {
      value: APMER,
      setValue: setAPMER,
    },
    PTR: {
      value: APPTR,
      setValue: setAPPTR,
    },
    PES: {
      value: APPES,
      setValue: setAPPES,
    },
    ASR: {
      value: APASR,
      setValue: setAPASR,
    },
    MERAQ: {
      value: APMERAQ,
      setValue: setAPMERAQ,
    },
    PRA: {
      value: APPRA,
      setValue: setAPPRA,
    },
    MEA: {
      value: APEA,
      setValue: setAPEA,
    },
    OMBR: {
      value: APOMBR,
      setValue: setAPOMBR,
    },
  };

  const [APMEA, setAPMEA] = useState<string>("Monthly");
  const [APMOC, setAPMOC] = useState<string>("Monthly");
  const [APCB, setAPCB] = useState<string>("Monthly");
  const [APCF, setAPCF] = useState<string>("Monthly");
  const [APCSR, setAPCSR] = useState<string>("Monthly");
  const [APCFAS, setAPCFAS] = useState<string>("Monthly");
  const [APCBAR, setAPCBAR] = useState<string>("Monthly");
  const [APReportType, setAPReportType] = useState<string>("Standard Report");
  const [APReport_Freq, setAPReport_Freq] = useState<string>("Monthly");

  const ApacClientReport: ClientReportType = {
    MEA: {
      value: APMEA,
      setValue: setAPMEA,
    },
    MOC: {
      value: APMOC,
      setValue: setAPMOC,
    },
    CB: {
      value: APCB,
      setValue: setAPCB,
    },
    CF: {
      value: APCF,
      setValue: setAPCF,
    },
    CSR: {
      value: APCSR,
      setValue: setAPCSR,
    },
    CFAS: {
      value: APCFAS,
      setValue: setAPCFAS,
    },
    CBAR: {
      value: APCBAR,
      setValue: setAPCBAR,
    },
    ReportType: {
      value: APReportType,
      setValue: setAPReportType,
    },
    Report_Freq: {
      value: APReport_Freq,
      setValue: setAPReport_Freq,
    },
  };

  const [APStructure, setAPStructure] = useState<string>("GMP");
  const [APSpendRatio, setAPSpendRatio] = useState<string>(
    "25% fixed; 75% variable"
  );
  const [APPrincipal, setAPPrincipal] = useState<string>(
    "Full Principal (immaterial agency spend)"
  );
  const [APCRL, setAPCRL] = useState<string>("Country-level");
  const [APTechStack, setAPTechStack] = useState<string>(
    "Standard - Mybuy/JDE/PS"
  );
  const [APAutomationAdj, setAPAutomationAdj] = useState<string>("High");
  const [APBankAccount, setAPBankAccount] = useState<string>("Dedicated");

  const ApacContractVariables: ContractVariablesType = {
    Structure: {
      value: APStructure,
      setValue: setAPStructure,
    },
    SpendRatio: {
      value: APSpendRatio,
      setValue: setAPSpendRatio,
    },
    Principal: {
      value: APPrincipal,
      setValue: setAPPrincipal,
    },
    CRL: {
      value: APCRL,
      setValue: setAPCRL,
    },
    TechStack: {
      value: APTechStack,
      setValue: setAPTechStack,
    },
    AutomationAdj: {
      value: APAutomationAdj,
      setValue: setAPAutomationAdj,
    },
    BankAccount: {
      value: APBankAccount,
      setValue: setAPBankAccount,
    },
  };

  const [APDelivery, setAPDelivery] = useState<string>("On-site");

  const ApacFD: RegionFDType = {
    Spend: {
      value: APSpend,
      setValue: setAPSpend,
    },
    Country_Sites: {
      value: APCountrySites,
      setValue: setAPCountrySites,
    },
    ContractVariables: ApacContractVariables,
    ARAP: ApacARAP,
    CBREReport: ApacCBREReport,
    ClientReport: ApacClientReport,
    DeliveryModel: {
      value: APDelivery,
      setValue: setAPDelivery,
    },
  };

  // State Variables for UI
  const [saveFM, setSaveFM] = useState<boolean>(false);
  const [saveAMSFD, setSaveAMSFD] = useState<boolean>(false);
  const [saveEMEAFD, setSaveEMEAFD] = useState<boolean>(false);
  const [saveAPACFD, setSaveAPACFD] = useState<boolean>(false);

  // FMResponse
  const [AMSRoleResponse, setAMSRoleResponse] = useState<string>("None");
  const [EMEARoleResponse, setEMEARoleResponse] = useState<string>("None");
  const [APACRoleResponse, setAPACRoleResponse] = useState<string>("None");
  const [GlobalRoleResponse, setGlobalRoleResponse] = useState<string>("None");

  const [AMSLocationResponse, setAMSLocationResponse] =
    useState<string>("None");
  const [EMEALocationResponse, setEMEALocationResponse] =
    useState<string>("None");
  const [APACLocationResponse, setAPACLocationResponse] =
    useState<string>("None");
  const [GlobalLocationResponse, setGlobalLocationResponse] =
    useState<string>("None");

  const [AMSFTEResponse, setAMSFTEResponse] = useState<number>(0);
  const [EMEAFTEResponse, setEMEAFTEResponse] = useState<number>(0);
  const [APACFTEResponse, setAPACFTEResponse] = useState<number>(0);
  const [GlobalFTEResponse, setGlobalFTEResponse] = useState<number>(0);

  // Total Finance Management
  const [totalFM, setTotalFM] = useState<number>(0);

  // AMS RB
  const [AMS_FARB, setAMS_FARB] = useState<number>(0);
  const [AMS_SFARB, setAMS_SFARB] = useState<number>(0);
  const [AMS_FMRB, setAMS_FMRB] = useState<number>(0);
  const [AMS_totalHrsRB, setAMS_totalHrsRB] = useState<number>(0);
  const [AMS_totalFTERB, setAMS_totalFTERB] = useState<number>(0);

  // EMEA RB
  const [EMEA_FARB, setEMEA_FARB] = useState<number>(0);
  const [EMEA_SFARB, setEMEA_SFARB] = useState<number>(0);
  const [EMEA_FMRB, setEMEA_FMRB] = useState<number>(0);
  const [EMEA_totalHrsRB, setEMEA_totalHrsRB] = useState<number>(0);
  const [EMEA_totalFTERB, setEMEA_totalFTERB] = useState<number>(0);

  // APAC RB
  const [APAC_FARB, setAPAC_FARB] = useState<number>(0);
  const [APAC_SFARB, setAPAC_SFARB] = useState<number>(0);
  const [APAC_FMRB, setAPAC_FMRB] = useState<number>(0);
  const [APAC_totalHrsRB, setAPAC_totalHrsRB] = useState<number>(0);
  const [APAC_totalFTERB, setAPAC_totalFTERB] = useState<number>(0);

  // AMS ML
  const [AMS_FAML, setAMS_FAML] = useState<number>(0);
  const [AMS_SFAML, setAMS_SFAML] = useState<number>(0);
  const [AMS_FMML, setAMS_FMML] = useState<number>(0);
  const [AMS_totalHrsML, setAMS_totalHrsML] = useState<number>(0);
  const [AMS_totalFTEML, setAMS_totalFTEML] = useState<number>(0);

  // EMEA ML
  const [EMEA_FAML, setEMEA_FAML] = useState<number>(0);
  const [EMEA_SFAML, setEMEA_SFAML] = useState<number>(0);
  const [EMEA_FMML, setEMEA_FMML] = useState<number>(0);
  const [EMEA_totalHrsML, setEMEA_totalHrsML] = useState<number>(0);
  const [EMEA_totalFTEML, setEMEA_totalFTEML] = useState<number>(0);

  // APAC ML
  const [APAC_FAML, setAPAC_FAML] = useState<number>(0);
  const [APAC_SFAML, setAPAC_SFAML] = useState<number>(0);
  const [APAC_FMML, setAPAC_FMML] = useState<number>(0);
  const [APAC_totalHrsML, setAPAC_totalHrsML] = useState<number>(0);
  const [APAC_totalFTEML, setAPAC_totalFTEML] = useState<number>(0);

  // Response Method Types for AMS
  const AMS_RB: ResponseMethodType = {
    FA: {
      value: AMS_FARB,
      setValue: setAMS_FARB,
    },
    SFA: {
      value: AMS_SFARB,
      setValue: setAMS_SFARB,
    },
    FM: {
      value: AMS_FMRB,
      setValue: setAMS_FMRB,
    },
    TotalHours: {
      value: AMS_totalHrsRB,
      setValue: setAMS_totalHrsRB,
    },
    TotalFTE: {
      value: AMS_totalFTERB,
      setValue: setAMS_totalFTERB,
    },
  };

  const AMS_ML: ResponseMethodType = {
    FA: {
      value: AMS_FAML,
      setValue: setAMS_FAML,
    },
    SFA: {
      value: AMS_SFAML,
      setValue: setAMS_SFAML,
    },
    FM: {
      value: AMS_FMML,
      setValue: setAMS_FMML,
    },
    TotalHours: {
      value: AMS_totalHrsML,
      setValue: setAMS_totalHrsML,
    },
    TotalFTE: {
      value: AMS_totalFTEML,
      setValue: setAMS_totalFTEML,
    },
  };

  // Response Method Types for EMEA
  const EMEA_RB: ResponseMethodType = {
    FA: {
      value: EMEA_FARB,
      setValue: setEMEA_FARB,
    },
    SFA: {
      value: EMEA_SFARB,
      setValue: setEMEA_SFARB,
    },
    FM: {
      value: EMEA_FMRB,
      setValue: setEMEA_FMRB,
    },
    TotalHours: {
      value: EMEA_totalHrsRB,
      setValue: setEMEA_totalHrsRB,
    },
    TotalFTE: {
      value: EMEA_totalFTERB,
      setValue: setEMEA_totalFTERB,
    },
  };

  const EMEA_ML: ResponseMethodType = {
    FA: {
      value: EMEA_FAML,
      setValue: setEMEA_FAML,
    },
    SFA: {
      value: EMEA_SFAML,
      setValue: setEMEA_SFAML,
    },
    FM: {
      value: EMEA_FMML,
      setValue: setEMEA_FMML,
    },
    TotalHours: {
      value: EMEA_totalHrsML,
      setValue: setEMEA_totalHrsML,
    },
    TotalFTE: {
      value: EMEA_totalFTEML,
      setValue: setEMEA_totalFTEML,
    },
  };

  // Response Method Types for APAC
  const APAC_RB: ResponseMethodType = {
    FA: {
      value: APAC_FARB,
      setValue: setAPAC_FARB,
    },
    SFA: {
      value: APAC_SFARB,
      setValue: setAPAC_SFARB,
    },
    FM: {
      value: APAC_FMRB,
      setValue: setAPAC_FMRB,
    },
    TotalHours: {
      value: APAC_totalHrsRB,
      setValue: setAPAC_totalHrsRB,
    },
    TotalFTE: {
      value: APAC_totalFTERB,
      setValue: setAPAC_totalFTERB,
    },
  };

  const APAC_ML: ResponseMethodType = {
    FA: {
      value: APAC_FAML,
      setValue: setAPAC_FAML,
    },
    SFA: {
      value: APAC_SFAML,
      setValue: setAPAC_SFAML,
    },
    FM: {
      value: APAC_FMML,
      setValue: setAPAC_FMML,
    },
    TotalHours: {
      value: APAC_totalHrsML,
      setValue: setAPAC_totalHrsML,
    },
    TotalFTE: {
      value: APAC_totalFTEML,
      setValue: setAPAC_totalFTEML,
    },
  };

  // Loading
  const [isFMLoading, setisFMLoading] = useState<boolean>(false);
  const [isFDLoading, setisFDLoading] = useState<boolean>(false);

  // Compiled Context
  const contextValue: MyContextType = {
    ClientName: {
      value: ClientName,
      setValue: setClientName,
    },
    FinanceManagement: {
      RegionalAssessment: {
        AMERICAS: AmericasFM,
        EMEA: EmeaFM,
        APAC: ApacFM,
      },
      GlobalAssessment: {
        Region: {
          value: Region,
          setValue: setRegion,
        },
        RoleRequirement: {
          value: RoleRequirement,
          setValue: setRoleRequirement,
        },
        Location: {
          value: GlobalLocation,
          setValue: setGlobalLocation,
        },
        Role: {
          value: GlobalRole,
          setValue: setGlobalRole,
        },
        Spend: {
          value: GlobalSpend,
          setValue: setGlobalSpend,
        },
      },
    },
    FinanceDelivery: {
      FDRegion: {
        value: FDRegion,
        setValue: setFDRegion,
      },
      AMERICAS: AmericasFD,
      EMEA: EmeaFD,
      APAC: ApacFD,
    },
    SaveFM: {
      value: saveFM,
      setValue: setSaveFM,
    },
    SaveFD: {
      AMS: {
        value: saveAMSFD,
        setValue: setSaveAMSFD,
      },
      EMEA: {
        value: saveEMEAFD,
        setValue: setSaveEMEAFD,
      },
      APAC: {
        value: saveAPACFD,
        setValue: setSaveAPACFD,
      },
    },
    FMResponse: {
      AMERICAS: {
        Role: {
          value: AMSRoleResponse,
          setValue: setAMSRoleResponse,
        },
        Location: {
          value: AMSLocationResponse,
          setValue: setAMSLocationResponse,
        },
        FTE: {
          value: AMSFTEResponse,
          setValue: setAMSFTEResponse,
        },
      },
      EMEA: {
        Role: {
          value: EMEARoleResponse,
          setValue: setEMEARoleResponse,
        },
        Location: {
          value: EMEALocationResponse,
          setValue: setEMEALocationResponse,
        },
        FTE: {
          value: EMEAFTEResponse,
          setValue: setEMEAFTEResponse,
        },
      },
      APAC: {
        Role: {
          value: APACRoleResponse,
          setValue: setAPACRoleResponse,
        },
        Location: {
          value: APACLocationResponse,
          setValue: setAPACLocationResponse,
        },
        FTE: {
          value: APACFTEResponse,
          setValue: setAPACFTEResponse,
        },
      },
      Global: {
        Role: {
          value: GlobalRoleResponse,
          setValue: setGlobalRoleResponse,
        },
        Location: {
          value: GlobalLocationResponse,
          setValue: setGlobalLocationResponse,
        },
        FTE: {
          value: GlobalFTEResponse,
          setValue: setGlobalFTEResponse,
        },
      },
      TotalFM: {
        value: totalFM,
        setValue: setTotalFM,
      },
    },
    FDResponse: {
      AMERICAS: {
        RB: AMS_RB,
        ML: AMS_ML,
      },
      EMEA: {
        RB: EMEA_RB,
        ML: EMEA_ML,
      },
      APAC: {
        RB: APAC_RB,
        ML: APAC_ML,
      },
    },
    isFMLoading: {
      value: isFMLoading,
      setValue: setisFMLoading,
    },
    isFDLoading: {
      value: isFDLoading,
      setValue: setisFDLoading,
    },
  };

  return (
    <MyContext.Provider value={contextValue}>{children}</MyContext.Provider>
  );
};
