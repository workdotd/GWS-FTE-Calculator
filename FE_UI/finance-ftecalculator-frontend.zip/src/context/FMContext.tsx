import { createContext } from "react";
import { ContextType } from "./ContextType";

// Define the shape of your context
export type MyContextType = {
  ClientName?: ContextType<string>;

  FinanceManagement?: {
    RegionalAssessment?: {
      AMERICAS?: RegionFMType;
      EMEA?: RegionFMType;
      APAC?: RegionFMType;
    };
    GlobalAssessment?: {
      Region?: ContextType<Array<string>>;
      RoleRequirement?: ContextType<string>;
      Location?: ContextType<string>;
      Role?: ContextType<string>;
      Spend?: ContextType<string>;
    };
  };

  FinanceDelivery?: {
    FDRegion?: ContextType<string>;
    AMERICAS?: RegionFDType;
    EMEA?: RegionFDType;
    APAC?: RegionFDType;
  };

  // For UI
  SaveFM: ContextType<boolean>;
  SaveFD: {
    AMS: ContextType<boolean>;
    EMEA: ContextType<boolean>;
    APAC: ContextType<boolean>;
  };

  // Responses
  isFMLoading: ContextType<boolean>;
  isFDLoading: ContextType<boolean>;
  FMResponse: FMResponseType;
  FDResponse: {
    AMERICAS: FDResponseType;
    EMEA: FDResponseType;
    APAC: FDResponseType;
  };
};

export type RegionFMType = {
  Role?: ContextType<string>;
  Growth?: ContextType<string>;
  Contract?: ContextType<string>;
  Performance?: ContextType<string>;
  Location?: ContextType<string>;
};

export type RegionFDType = {
  // Float till 2 decimal
  Spend: ContextType<number>;
  // Country and Sites for each of the country in the array
  Country_Sites: ContextType<Map<string, number>>;

  ContractVariables: ContractVariablesType;
  ARAP: ARAPType;
  CBREReport: CBREReportType;
  ClientReport: ClientReportType;

  DeliveryModel: ContextType<string>;
};

export type ContractVariablesType = {
  Structure: ContextType<string>;
  SpendRatio: ContextType<string>;
  Principal: ContextType<string>;
  CRL: ContextType<string>;
  TechStack: ContextType<string>;
  AutomationAdj: ContextType<string>;
  BankAccount: ContextType<string>;
};

export type ARAPType = {
  Billing: ContextType<string>;
  FundRecon: ContextType<string>;
  Payment: ContextType<string>;
};

export type CBREReportType = {
  OpenPOReview: ContextType<string>;
  BalanceSheetRecon: ContextType<string>;
  MER: ContextType<string>;
  PTR: ContextType<string>;
  PES: ContextType<string>;
  ASR: ContextType<string>;
  MERAQ: ContextType<string>;
  PRA: ContextType<string>;
  OMBR: ContextType<string>;
  MEA: ContextType<string>;
};

export type ClientReportType = {
  MEA: ContextType<string>;
  MOC: ContextType<string>;
  CB: ContextType<string>;
  CF: ContextType<string>;
  CSR: ContextType<string>;
  CFAS: ContextType<string>;
  CBAR: ContextType<string>;
  ReportType: ContextType<string>;
  Report_Freq: ContextType<string>;
};

export type FMResponseType = {
  AMERICAS: FMResponseRegionType;
  EMEA: FMResponseRegionType;
  APAC: FMResponseRegionType;
  Global: FMResponseRegionType;
  TotalFM: ContextType<number>;
};

export type FMResponseRegionType = {
  Role: ContextType<string>;
  Location: ContextType<string>;
  FTE: ContextType<number>;
};

export type FDResponseType = {
  RB?: ResponseMethodType;
  ML?: ResponseMethodType;
};

export type ResponseMethodType = {
  FA: ContextType<number>;
  SFA: ContextType<number>;
  FM: ContextType<number>;
  TotalHours: ContextType<number>;
  TotalFTE: ContextType<number>;
};
// Create the context with a default value
export const MyContext = createContext<MyContextType | undefined>(undefined);
