export type ContextType<T> = {
    value: T;
    setValue: React.Dispatch<React.SetStateAction<T>>;
}