import React from "react";
import { ContextType } from "../context/ContextType";

// Financial Management
export const handleChangeFM = (e: React.MouseEvent<Element, MouseEvent> | React.KeyboardEvent<Element>, value: unknown, changeState: React.Dispatch<React.SetStateAction<string>>| undefined, save: ContextType<boolean>, changeErrorState?: React.Dispatch<React.SetStateAction<boolean>> | undefined) => {
    // return;
    // e.stopPropagation();
    // e.preventDefault();
    // e.nativeEvent.stopImmediatePropagation();
    // e.nativeEvent.stopPropagation();

    save.setValue(false);

    if(changeState && value) {
      const inputValue = value; // Assert that value is of type ValueType[]
      if(typeof inputValue === 'string') {
        changeState(inputValue)
      }
      else if (typeof inputValue === 'object') {
        changeState(inputValue[0]);
      }
      if(changeErrorState && inputValue !== 'None') {
        changeErrorState(true);
      }
    } else {
      throw(new Error("Type Error: Passed undefined"))
    }
};

export const handleCheckBoxChangeFM = (value: string, state: ContextType<Array<string>> | undefined, errorState?: React.Dispatch<React.SetStateAction<boolean>>) => {
  if (state?.value.includes(value)) {
      // If the item exists, remove it
      state?.setValue((prevItems: any[]) => prevItems.filter(i => i !== value));
  } else {
      // If the item does not exist, add it
      state?.setValue((prevItems: any) => [...prevItems, value]);
  }

  if(errorState) {
    errorState(true)
  }
}

// Financial Delivery