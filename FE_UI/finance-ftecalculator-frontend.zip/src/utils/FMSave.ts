import { MyContextType } from "../context/FMContext";
import { validateFMInput } from "./Validations";

// Defining an interface for the expected structure of the JSON object

// Possible Optimization
// export interface FMAPIFormat {
//     "RA Region": Array<string | undefined>;
//     "Selected Role": Array<string | undefined>;
//     "Contract Value": Array<string | undefined>;
//     "Performance Risk": Array<string | undefined>;
//     "Growth Opportunity": Array<string | undefined>;

//     "GA Region": number | undefined;
//     "Global Role Req": string | undefined;
//     "Global Managed Spend": string | undefined;
//     "location": string | undefined;
// }

export interface FMAPIFormat {
  "RA Region": string | undefined;
  "Selected Role": string | undefined;
  "Contract Value": string | undefined;
  "Performance Risk": string | undefined;
  "Growth Opportunity": string | undefined;

  "GA Region_count": number | undefined;
  "Global Role Req": string | undefined;
  "Global Managed Spend": string | undefined;
  location: string | undefined;
}

export interface FMResponseFormat {
  index: string | undefined;
  Role: string | undefined;
  FTE: number | undefined;
  location: string | undefined;
}

// Function that returns a JSON object
export const setFMAPIData = (context: MyContextType): FMAPIFormat[] => {
  validateFMInput(context);

  const Global = context.FinanceManagement?.GlobalAssessment;
  const Regional = context.FinanceManagement?.RegionalAssessment;
  var GlobalSpend: any = "";

  const AMERICAS = Regional?.AMERICAS;
  const EMEA = Regional?.EMEA;
  const APAC = Regional?.APAC;

  // Somewhat like validation
  if (Global?.RoleRequirement?.value === "Yes") {
    GlobalSpend = "None";
  } else {
    GlobalSpend = Global?.Spend?.value;
  }

  const americasJson: FMAPIFormat = {
    "GA Region_count": Global?.Region?.value.length,
    "Global Role Req": Global?.RoleRequirement?.value,
    "Global Managed Spend": GlobalSpend,
    location: Global?.Location?.value,

    "RA Region": "AMERICAS",
    "Selected Role": AMERICAS?.Role?.value,
    "Contract Value": AMERICAS?.Contract?.value,
    "Performance Risk": AMERICAS?.Performance?.value,
    "Growth Opportunity": AMERICAS?.Growth?.value,
  };

  const emeaJson: FMAPIFormat = {
    "GA Region_count": Global?.Region?.value.length,
    "Global Role Req": Global?.RoleRequirement?.value,
    "Global Managed Spend": GlobalSpend,
    location: Global?.Location?.value,

    "RA Region": "EMEA",
    "Selected Role": EMEA?.Role?.value,
    "Contract Value": EMEA?.Contract?.value,
    "Performance Risk": EMEA?.Performance?.value,
    "Growth Opportunity": EMEA?.Growth?.value,
  };

  const apacJson = {
    "GA Region_count": Global?.Region?.value.length,
    "Global Role Req": Global?.RoleRequirement?.value,
    "Global Managed Spend": GlobalSpend,
    location: Global?.Location?.value,

    "RA Region": "APAC",
    "Selected Role": APAC?.Role?.value,
    "Contract Value": APAC?.Contract?.value,
    "Performance Risk": APAC?.Performance?.value,
    "Growth Opportunity": APAC?.Growth?.value,
  };

  return [americasJson, emeaJson, apacJson]; // This will be returned as JSON when serialized
};

export const setFMResponseData = (
  context: MyContextType,
  response: Array<FMResponseFormat>
) => {
  response.map(({ index, FTE, Role, location }) => {
    if (index === "AMERICAS") {
      context.FMResponse.AMERICAS.FTE.setValue(FTE ?? 0);
      context.FMResponse.AMERICAS.Role.setValue(Role ?? "None");
      // context.FMResponse.AMERICAS.Location.setValue(location ?? "None");
    } else if (index === "EMEA") {
      context.FMResponse.EMEA.FTE.setValue(FTE ?? 0);
      context.FMResponse.EMEA.Role.setValue(Role ?? "None");
      // context.FMResponse.EMEA.Location.setValue(location ?? "None");
    } else if (index === "APAC") {
      context.FMResponse.APAC.FTE.setValue(FTE ?? 0);
      context.FMResponse.APAC.Role.setValue(Role ?? "None");
      // context.FMResponse.APAC.Location.setValue(location ?? "None");
    } else if (index === "Global Role") {
      context.FMResponse.Global.FTE.setValue(FTE ?? 0);
      context.FMResponse.Global.Role.setValue(Role ?? "No Role Recommended");
      context.FinanceManagement?.GlobalAssessment?.Role?.setValue(
        Role ?? "No Role Recommended"
      );
      // context.FMResponse.Global.Location.setValue(location ?? "None");
    } else if (index === "Total Finance Management" && FTE) {
      context.FMResponse?.TotalFM?.setValue(FTE ?? 0);
    }
  });
};
