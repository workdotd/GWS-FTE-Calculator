import { MyContextType, RegionFDType } from "../context/FMContext";
import { getRegionSummary } from "./GetValues";
import { validateFDInput } from "./Validations";

export interface FDAPIFormat {
  "Client Name": string | undefined;
  Country: string | undefined;
  Region: string | undefined;
  "Total Managed Spend": number | undefined;
  "Number of Sites": number | undefined;
  "Delivery Model": string | undefined;
  "Contract Structure Option": string | undefined;
  "Spend Ratio Option": string | undefined;
  "Principal/MA Option": string | undefined;
  "Client Reporting Level Option": string | undefined;
  "Tech Stack Option": string | undefined;
  "Automation Adjustment Option": string | undefined;
  "Bank Account Option": string | undefined;

  // Frequency options as strings
  "1.Billing_freq": string | undefined;
  "2.Fund Reconciliations_freq": string | undefined;
  "3.Payment_freq": string | undefined;
  "4.Monthly JDE period close and Open PO review_freq": string | undefined;
  "5.Monthly JDE Balance Sheet Reconciliation_freq": string | undefined;
  "6.Corporate Month End Revenue/Costs Adjustments_freq": string | undefined;
  "7.Corporate Pass Through Reconciliation_freq": string | undefined;
  "8.Corporate Payment Entries Submission_freq": string | undefined;
  "9.Internal & External Audit Sampling Requests (SOC1 & SOX)_freq":
    | string
    | undefined;
  "10.Corporate P&L Month End Review, Analysis & Queries_freq":
    | string
    | undefined;
  "11.Corporate Yearly Budget - Preparation, Review & Approval_freq":
    | string
    | undefined;
  "12.Corporate Monthly Forecast - Preparation, Review & Approval_freq":
    | string
    | undefined;
  "13.Corporate Operation Merit & Bonus Review_freq": string | undefined;
  "14.Client Month End Accruals - Open PO, Rental, Utilities etc. - Manual Journal Entries Posting_freq":
    | string
    | undefined;
  "15.Monthly Operational Call for Client Month End Close (Queries from FM - Finance Related)_freq":
    | string
    | undefined;
  "16.Client Budget - Management Fee & Payroll Calculation; Vendor Spend Data_freq":
    | string
    | undefined;
  "17.Client Forecast - Vendor Spend_freq": string | undefined;
  "18.Client Savings Report_freq": string | undefined;
  "19.Client Finance Audit Support_freq": string | undefined;
  "20.Client Billing to Actuals Reconciliation_freq": string | undefined;

  // Standard and Customized Report frequencies
  "Standard Report_freq": string | undefined;
  "Customised Report_freq": string | undefined;
}

export interface FDResponseFormat {
  index: string | undefined;
  "Rule Based": number | undefined;
  "ML Predicted": number | undefined;
}

export interface FDActivitySummary {
  Activities: string | undefined;
  Hours: number | undefined;
}

export const FDAPIRegionBased = (context: MyContextType): FDAPIFormat[] => {
  var data: FDAPIFormat[] = [];
  const fdregion = context?.FinanceDelivery?.FDRegion?.value;

  if (fdregion === "AMERICAS") {
    data = setFDAPIData(
      context.FinanceDelivery?.AMERICAS,
      context.ClientName?.value,
      "AMS"
    );
  } else if (fdregion === "EMEA") {
    data = setFDAPIData(
      context.FinanceDelivery?.EMEA,
      context.ClientName?.value,
      fdregion
    );
  } else if (fdregion === "APAC") {
    data = setFDAPIData(
      context.FinanceDelivery?.APAC,
      context.ClientName?.value,
      fdregion
    );
  } else {
    throw new Error("Incorrect region");
  }

  return data;
};

export const setFDAPIData = (
  context: RegionFDType | undefined,
  clientName: string | undefined,
  region: string
): FDAPIFormat[] => {
  const ContractVariables = context?.ContractVariables;
  const CBREReport = context?.CBREReport;
  const ClientReport = context?.ClientReport;
  const ARAP = context?.ARAP;

  var data: FDAPIFormat[] = [];

  // Validations
  validateFDInput(context, clientName);

  context?.Country_Sites.value.forEach((value, key) => {
    const entry: FDAPIFormat = {
      "Client Name": clientName,
      Country: key, // Assuming this remains empty as in your original example
      Region: region, // Ensure region is defined elsewhere in your code
      "Total Managed Spend": context.Spend.value,
      "Number of Sites": value,

      "Delivery Model": context?.DeliveryModel?.value,
      "Contract Structure Option": ContractVariables?.Structure?.value,
      "Spend Ratio Option": ContractVariables?.SpendRatio?.value,
      "Principal/MA Option": ContractVariables?.Principal?.value,
      "Client Reporting Level Option": ContractVariables?.CRL?.value,
      "Tech Stack Option": ContractVariables?.TechStack?.value,
      "Automation Adjustment Option": ContractVariables?.AutomationAdj?.value,
      "Bank Account Option": ContractVariables?.BankAccount?.value,

      "1.Billing_freq": ARAP?.Billing?.value,
      "2.Fund Reconciliations_freq": ARAP?.FundRecon?.value,
      "3.Payment_freq": ARAP?.Payment?.value,

      "4.Monthly JDE period close and Open PO review_freq":
        CBREReport?.OpenPOReview?.value,
      "5.Monthly JDE Balance Sheet Reconciliation_freq":
        CBREReport?.BalanceSheetRecon?.value,
      "6.Corporate Month End Revenue/Costs Adjustments_freq":
        CBREReport?.MER?.value,
      "7.Corporate Pass Through Reconciliation_freq": CBREReport?.PTR?.value,
      "8.Corporate Payment Entries Submission_freq": CBREReport?.PES?.value,
      "9.Internal & External Audit Sampling Requests (SOC1 & SOX)_freq":
        CBREReport?.ASR?.value,
      "10.Corporate P&L Month End Review, Analysis & Queries_freq":
        CBREReport?.MERAQ?.value,
      "11.Corporate Yearly Budget - Preparation, Review & Approval_freq":
        CBREReport?.PRA?.value,
      "12.Corporate Monthly Forecast - Preparation, Review & Approval_freq":
        CBREReport?.MEA?.value,
      "13.Corporate Operation Merit & Bonus Review_freq":
        CBREReport?.OMBR?.value,

      "14.Client Month End Accruals - Open PO, Rental, Utilities etc. - Manual Journal Entries Posting_freq":
        ClientReport?.MEA?.value,
      "15.Monthly Operational Call for Client Month End Close (Queries from FM - Finance Related)_freq":
        ClientReport?.MOC?.value,
      "16.Client Budget - Management Fee & Payroll Calculation; Vendor Spend Data_freq":
        ClientReport?.CB?.value,
      "17.Client Forecast - Vendor Spend_freq": ClientReport?.CF?.value,
      "18.Client Savings Report_freq": ClientReport?.CSR?.value,
      "19.Client Finance Audit Support_freq": ClientReport?.CFAS?.value,
      "20.Client Billing to Actuals Reconciliation_freq":
        ClientReport?.CBAR?.value,

      // Based on Report Type
      "Standard Report_freq":
        ClientReport?.ReportType.value === "Standard Report"
          ? ClientReport.Report_Freq.value
          : "None", // Assuming you want to keep it as null
      "Customised Report_freq":
        ClientReport?.ReportType.value === "Customised Report"
          ? ClientReport.Report_Freq.value
          : "None", // Assuming this remains an empty string
    };
    data.push(entry);
  });

  return data;
};

export const setFDResponse = (
  context: MyContextType | undefined,
  response: FDResponseFormat[]
) => {
  const region = getRegionSummary(context);
  const RB = region?.RB;
  const ML = region?.ML;

  //   console.log("HI");
  response.forEach((data) => {
    if (data["ML Predicted"] != null) {
      if (data.index === "Total Hours") {
        ML?.TotalHours.setValue(data["ML Predicted"]);
      } else if (data.index === "Total FTE Count") {
        ML?.TotalFTE.setValue(data["ML Predicted"]);
      } else if (data.index === "Financial Analyst") {
        ML?.FA.setValue(data["ML Predicted"]);
      } else if (data.index === "Sr. Financial Analyst") {
        ML?.SFA.setValue(data["ML Predicted"]);
      } else if (data.index === "Manager/Team-Lead") {
        ML?.FM.setValue(data["ML Predicted"]);
      }
    }

    if (data["Rule Based"] != null) {
      if (data.index === "Total Hours") {
        RB?.TotalHours.setValue(data["Rule Based"]);
      } else if (data.index === "Total FTE Count") {
        RB?.TotalFTE.setValue(data["Rule Based"]);
      } else if (data.index === "Financial Analyst") {
        console.log("HI");
        RB?.FA.setValue(data["Rule Based"]);
      } else if (data.index === "Sr. Financial Analyst") {
        RB?.SFA.setValue(data["Rule Based"]);
      } else if (data.index === "Manager/Team-Lead") {
        RB?.FM.setValue(data["Rule Based"]);
      }
    }
  });
};
