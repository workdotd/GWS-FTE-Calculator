// src/axiosInstance.ts
import axios, { InternalAxiosRequestConfig } from "axios";

// Create an Axios instance
const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_BASE_URL, // Set your API base URL here
  // baseURL : "https://finance-ftecalculator-dev2.cbre.com/api/",
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
  },
});

// Add a request interceptor
axiosInstance.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    // Do something before the request is sent
    const token = sessionStorage.getItem("token"); // Retrieve auth token from sessionStorage

    if (token) {
      config.headers.Authorization = `Bearer ${token}`; // Attach token to headers
    } else {
      console.warn("No Auth Token Found");
    }

    // console.log('Request:', config); // Log the request details for debugging
    return config; // Return the modified config
  },
  (error) => {
    // Handle the error
    return Promise.reject(error); // Reject the promise with the error
  }
);

export default axiosInstance;
