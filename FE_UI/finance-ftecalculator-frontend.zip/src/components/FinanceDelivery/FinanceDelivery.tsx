import React, { useContext } from 'react';
import "../../styles/FinanceDelivery.scss";
import RegionsFD from '../RegionsFD/RegionsFD';
import { MyContext } from '../../context/FMContext';

interface FinanceDeliveryProps {
  scrollableRef: React.RefObject<HTMLDivElement>;
  scrollToTop: () => void;
}

const FinanceDelivery: React.FC<FinanceDeliveryProps> = (props) => {

  const context = useContext(MyContext);
  const FDRegion = context?.FinanceDelivery?.FDRegion;

  return (
    <>
      <div className="fd-container">
        {/* <div className="fd-title">Finance Delivery</div> */}

        <div className="fd-nav-container">
          <div className="fd-nav-regions">
            <span className={FDRegion?.value ==="AMERICAS"?'active':''} onClick={() => {FDRegion?.setValue("AMERICAS"); props.scrollToTop()}}>AMERICAS</span>
            <span className={FDRegion?.value ==="EMEA"?'active':''} onClick={() => {FDRegion?.setValue("EMEA"); props.scrollToTop()}}>EMEA</span>
            <span className={FDRegion?.value ==="APAC"?'active':''} onClick={() => {FDRegion?.setValue("APAC"); props.scrollToTop()}}>APAC</span>
          </div>
          <hr />
        </div>

        <div className="fd-form" ref={props.scrollableRef}>
          <RegionsFD />
        </div>
      </div>
    </>
  );
};

export default FinanceDelivery;
