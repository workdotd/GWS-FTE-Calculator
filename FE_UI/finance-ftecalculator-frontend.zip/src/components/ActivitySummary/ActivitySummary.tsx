import React, { useContext, useEffect, useState } from "react";

import { EmeraldButton } from "@emerald-react/button";
import { EmeraldProgressSpinner } from "@emerald-react/progress-indicator";
import { EmeraldButtonVariant } from "@emerald/nxcore";

import "../../styles/ActivitySummary.scss";
import "../../styles/ActivitySummaryTable.scss";

import { MyContext, RegionFDType } from "../../context/FMContext";
import {
  FDAPIFormat,
  FDActivitySummary,
  setFDAPIData,
} from "../../utils/FDSave";
import axiosInstance from "../../utils/interceptor";
import { getRegion } from "../../utils/GetValues";

import ATable from "./ATable";

interface ActivitySummaryProps {
  setActivitySummary: React.Dispatch<React.SetStateAction<boolean>>;
}

const ActivitySummary: React.FC<ActivitySummaryProps> = (props) => {
  const context = useContext(MyContext);
  var region: RegionFDType | undefined;

  const [tableRows, setTableRows] = useState<FDActivitySummary[]>([]);
  const [ActivitySummaryError, setActivitySummaryError] = useState(false);

  region = getRegion(context);

  const handleActivitySummary = () => {
    var data: FDAPIFormat[] = [];
    const fdregion = context?.FinanceDelivery?.FDRegion?.value;
    if (fdregion === "AMERICAS") {
      data = setFDAPIData(region, context?.ClientName?.value, "AMS");
    } else if (fdregion === "EMEA") {
      data = setFDAPIData(region, context?.ClientName?.value, fdregion);
    } else if (fdregion === "APAC") {
      data = setFDAPIData(region, context?.ClientName?.value, fdregion);
    } else {
      console.log("Incorrect region");
    }
    // console.log(data);
    fetchActivitySummary(data);
  };

  const fetchActivitySummary = async (postData: FDAPIFormat[]) => {
    try {
      const response = await axiosInstance.post(
        "calculate_fte/activity_summary",
        postData
      );
      setTableRows(response.data);
      //   console.log(json);
    } catch (error) {
      console.log(error);
      setActivitySummaryError(true);
    } finally {
      console.log("API hitted");
    }
  };

  useEffect(() => {
    handleActivitySummary();
  }, [region]);

  return (
    <>
      <div className="activity-container">
        <div className="activity-nav">
          <h6 className="activity-title">
            Activity Summary: {context?.FinanceDelivery?.FDRegion?.value}
          </h6>
          <div className="activity-nav-btn">
            <EmeraldButton
              label="Back"
              icon="arrow_back"
              type={EmeraldButtonVariant.Light}
              onClick={() => {
                props.setActivitySummary(false);
              }}
            />
          </div>
        </div>
        {ActivitySummaryError ? (
          <>
            <ATable />
          </>
        ) : (
          <div className="activity-summary">
            {tableRows.length ? (
              <table className="table">
                <thead className="thead">
                  <tr className="tr">
                    <th>Finance Activity</th>
                    <th>
                      {context?.FinanceDelivery?.FDRegion?.value === "AMERICAS"
                        ? "AMS"
                        : context?.FinanceDelivery?.FDRegion?.value}
                    </th>
                  </tr>
                </thead>
                <tbody className="tbody">
                  {tableRows.map((row) => {
                    return (
                      <>
                        <tr className="tr">
                          <td>{row.Activities}</td>
                          <td>{row.Hours}</td>
                        </tr>
                      </>
                    );
                  })}
                  {/* <tr className='tr'>
                                  <td><b>Total Est. Hours per Month</b></td>
                                  <td>{context?.TotalHrsRB.value}</td>
                              </tr> */}
                </tbody>
              </table>
            ) : (
              <div className="loader">
                <EmeraldProgressSpinner determinate={false} />
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default ActivitySummary;
