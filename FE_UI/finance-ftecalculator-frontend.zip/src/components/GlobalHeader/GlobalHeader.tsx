import React from 'react';

import "../../styles/GlobalHeader.scss";

const GlobalHeader: React.FC = () => {
  return (
    <>
      <div className="header-container">
        <h6 className="header-title">
          <img src={process.env.PUBLIC_URL+'/CBRE_white.png'} alt="logo" /> 
          <span>&nbsp; &nbsp; | &nbsp; GWS Enterprise Finance</span>
        </h6>
      </div>
    </>
  );
};

export default GlobalHeader;
