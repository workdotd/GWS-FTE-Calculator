import React, { useContext, useEffect } from "react";

import { EmeraldDropdown } from "@emerald-react/dropdown";

import RegionsFM from "../RegionsFM/RegionsFM";
import { MyContext } from "../../context/FMContext";
import {
  AmericasRoleLocations,
  ApacRoleLocations,
  EmeaRoleLocations,
} from "../../data/RoleLocations";
import { handleChangeFM } from "../../utils/handleChange";
import { ErrorContext } from "../../context/ErrorContext";

const RegionalAssessment: React.FC = () => {
  const context = useContext(MyContext);
  const errorContext = useContext(ErrorContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  const AMERICAS = context.FinanceManagement?.RegionalAssessment?.AMERICAS;
  const EMEA = context.FinanceManagement?.RegionalAssessment?.EMEA;
  const APAC = context.FinanceManagement?.RegionalAssessment?.APAC;

  const AMSError = errorContext?.FinanceManagement.AMERICAS;
  const EMEAError = errorContext?.FinanceManagement.EMEA;
  const APACError = errorContext?.FinanceManagement.APAC;

  const AllNone = errorContext?.FinanceManagement.AllNone;

  useEffect(() => {
    AmericasRoleLocations[0].selected = true;
    EmeaRoleLocations[0].selected = true;
    ApacRoleLocations[0].selected = true;
  }, []);

  return (
    <>
      <div className="fm-section">
        {/* <h6 className="fm-form-assessment-title">Regional Assessment</h6> */}

        {AllNone?.value ? (
          <span className="All-none-error-text">
            Atleast One Region must be filled
          </span>
        ) : (
          <></>
        )}

        <RegionsFM
          name="Americas"
          context={AMERICAS}
          errorContext={AMSError}
          save={context.SaveFM}
        />
        <RegionsFM
          name="Emea"
          context={EMEA}
          errorContext={EMEAError}
          save={context.SaveFM}
        />
        <RegionsFM
          name="Apac"
          context={APAC}
          errorContext={APACError}
          save={context.SaveFM}
        />

        <div className="fm-sub-section">
          <h6 className="fm-sections-desc">
            Recommended Regional Finance Management Roles
          </h6>

          <div className="fm-sub-sub-section header">
            <span className="fm-sub-sub-section-input"></span>
            <span className="fm-sub-sub-section-input">AMERICAS</span>
            <span className="fm-sub-sub-section-input">EMEA</span>
            <span className="fm-sub-sub-section-input">APAC</span>
          </div>

          <div className="fm-sub-sub-section">
            <span className="fm-sub-sub-section-input">Recommended Role:</span>
            <span className="fm-sub-sub-section-input">
              {AMERICAS?.Role?.value}
            </span>
            <span className="fm-sub-sub-section-input">
              {EMEA?.Role?.value}
            </span>
            <span className="fm-sub-sub-section-input">
              {APAC?.Role?.value}
            </span>
          </div>

          <div className="fm-sub-sub-section">
            <span className="fm-sub-sub-section-input">
              Indicate country-location of role:
            </span>
            <span className="fm-sub-sub-section-input">
              <EmeraldDropdown
                label="AMERICAS Role"
                outlined
                id="single_select"
                // preSelectedValue='Peru'
                onChange={(e, value) => {
                  handleChangeFM(
                    e,
                    value,
                    AMERICAS?.Location?.setValue,
                    context.SaveFM
                  );
                }}
                options={AmericasRoleLocations}
              />
            </span>

            <span className="fm-sub-sub-section-input">
              <EmeraldDropdown
                label="EMEA Role"
                outlined
                id="single_select"
                onChange={(e, value) => {
                  handleChangeFM(
                    e,
                    value,
                    EMEA?.Location?.setValue,
                    context.SaveFM
                  );
                }}
                options={EmeaRoleLocations}
              />
            </span>

            <span className="fm-sub-sub-section-input">
              <EmeraldDropdown
                label="APAC Role"
                outlined
                id="single_select"
                onChange={(e, value) => {
                  handleChangeFM(
                    e,
                    value,
                    APAC?.Location?.setValue,
                    context.SaveFM
                  );
                }}
                options={ApacRoleLocations}
              />
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default RegionalAssessment;
