import React, { useContext } from "react";
import { MyContext } from "../../context/FMContext";

import { EmeraldRadio, EmeraldRadioGroup } from "@emerald-react/radio";
import { EmeraldCheckbox } from "@emerald-react/checkbox";
import { EmeraldDropdown } from "@emerald-react/dropdown";
import { GlobalRoleLocations } from "../../data/RoleLocations";
import {
  handleChangeFM,
  handleCheckBoxChangeFM,
} from "../../utils/handleChange";
import { ErrorContext } from "../../context/ErrorContext";

const GlobalAssessment: React.FC = () => {
  const context = useContext(MyContext);
  const errorContext = useContext(ErrorContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  const Global = context.FinanceManagement?.GlobalAssessment;
  const GlobalError = errorContext?.FinanceManagement.Global;

  return (
    <>
      <div className="fm-section">
        {/* <h6 className="fm-form-assessment-title">Global Assessment</h6> */}

        <div className="fm-sub-section">
          <h6 className="fm-sections-desc">
            Indicate the regions in scope under this deal
          </h6>
          <div className="horizontal">
            <EmeraldCheckbox
              label="AMERICAS"
              checked={
                Global?.Region?.value?.includes("AMERICAS") ? true : false
              }
              onChange={(checked, e) => {
                handleCheckBoxChangeFM(
                  "AMERICAS",
                  Global?.Region,
                  GlobalError?.Region.setValue
                );
              }}
            />
            <EmeraldCheckbox
              label="EMEA"
              checked={Global?.Region?.value?.includes("EMEA") ? true : false}
              onChange={(checked, e) => {
                handleCheckBoxChangeFM(
                  "EMEA",
                  Global?.Region,
                  GlobalError?.Region.setValue
                );
              }}
            />
            <EmeraldCheckbox
              label="APAC"
              checked={Global?.Region?.value?.includes("APAC") ? true : false}
              onChange={(checked, e) => {
                handleCheckBoxChangeFM(
                  "APAC",
                  Global?.Region,
                  GlobalError?.Region.setValue
                );
              }}
            />
          </div>
          {GlobalError?.Region.value ? (
            <></>
          ) : (
            <span className="error">This is a required field</span>
          )}
        </div>

        <div className="fm-sub-section">
          <h6 className="fm-sections-desc">
            Is there a clear client requirement to hire a global finance leader
            role?
          </h6>
          <EmeraldRadioGroup
            orientation="horizontal"
            defaultSelected={Global?.RoleRequirement?.value}
            onChange={(value, _name, e) => {
              handleChangeFM(
                e,
                value,
                Global?.RoleRequirement?.setValue,
                context.SaveFM
              );
            }}
          >
            <EmeraldRadio label="Yes" value="Yes" />
            <EmeraldRadio label="No" value="No" />
          </EmeraldRadioGroup>
          {GlobalError?.Requirement.value ? (
            <></>
          ) : (
            <span className="error">This field is required</span>
          )}
        </div>

        {Global?.RoleRequirement?.value === "Yes" ? (
          <></>
        ) : (
          <div className="fm-sub-section">
            <h6 className="fm-sections-desc">
              Indicate the total global managed spend under this deal?
            </h6>
            <EmeraldRadioGroup
              orientation="horizontal"
              defaultSelected={Global?.Spend?.value}
              onChange={(value, _name, e) => {
                handleChangeFM(
                  e,
                  value,
                  Global?.Spend?.setValue,
                  context.SaveFM
                );
              }}
            >
              <EmeraldRadio
                label="Below 50M Managed Spend"
                value="Below 50M Managed Spend"
              />
              <EmeraldRadio
                label="Above 50M Managed Spend"
                value="Above 50M Managed Spend"
              />
            </EmeraldRadioGroup>

            {GlobalError?.Spend.value ? (
              <></>
            ) : (
              <span className="error">This field is required</span>
            )}
          </div>
        )}

        <div className="fm-sub-section">
          <h6 className="fm-sections-desc">
            Recommended Global Financial Management Role
          </h6>
          <div className="fm-sub-section-global-role vertical">
            <div className="fm-sub-sub-section-global">
              <span>Recommended Role:</span>
              <span>{Global?.Role?.value}</span>
            </div>

            <div className="role-location fm-sub-sub-section-global">
              <EmeraldDropdown
                label="Country location of Role"
                outlined
                id="single_select"
                onChange={(e, value) => {
                  handleChangeFM(
                    e,
                    value,
                    Global?.Location?.setValue,
                    context.SaveFM
                  );
                }}
                options={GlobalRoleLocations}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GlobalAssessment;
