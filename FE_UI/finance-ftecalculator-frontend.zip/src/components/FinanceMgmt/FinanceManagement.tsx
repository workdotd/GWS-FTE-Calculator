import React, { useContext, useState } from 'react';

import { EmeraldAccordionGroup } from "@emerald-react/accordion-group";

import '../../styles/FinanceManagement.scss';
import { MyContext } from '../../context/FMContext';
import RegionalAssessment from './RegionalAssessment';
import GlobalAssessment from './GlobalAssessment';

interface FinanceManagementProps {
    scrollableRef: React.RefObject<HTMLDivElement>;
}

const FinanceManagement: React.FC<FinanceManagementProps> = (props) => {

  const context = useContext(MyContext);

  if (!context) {
    throw new Error('FinanceManagement must be used within a MyProvider');
  }

  const [RegionAccordian, setRegionAccordian] = useState(false);
  const [GlobalAccordian, setGlobalAccordian] = useState(false);

  return (
    <>
      <div className="fm-container">
        {/* <h5 className="fm-title">Finance Management</h5> */}
        
        <h6 className="fm-sections-desc">Is there a clear client requirement to hire a specific finance leader role from at least 1 region?</h6>
        
        <div className="fm-form" ref={props.scrollableRef}>

          <EmeraldAccordionGroup
            data={[
              {
                children: <RegionalAssessment />,
                title: "Regional Assessment",
                openIcon: "keyboard_arrow_up",
                closeIcon: "keyboard_arrow_down",
                iconPosition: "right",
                className: 'fm-accordian',
                open: RegionAccordian,
                onToggle: setRegionAccordian
              },
              {
                children: <GlobalAssessment />,
                title: "Global Assessment",
                openIcon: "keyboard_arrow_up",
                closeIcon: "keyboard_arrow_down",
                iconPosition: "right",
                className: "fm-accordian",
                open: GlobalAccordian,
                onToggle: setGlobalAccordian
              },
            ]}
          />

        </div>
      </div>
    </>
  );
};

export default FinanceManagement;
