import React from "react";

import { EmeraldDropdown } from "@emerald-react/dropdown";

import "../../styles/RegionsFM.scss";

import { Options } from "../../data/Options";
import { RegionFMType } from "../../context/FMContext";
import { ContextType } from "../../context/ContextType";
import { setOptions } from "../../utils/GetValues";
import { RegionFMErrorType } from "../../context/ErrorContext";
import { handleChangeFM } from "../../utils/handleChange";

interface RegionsFMProps {
  name: string;
  context?: RegionFMType;
  errorContext?: RegionFMErrorType;
  save: ContextType<boolean>;
}

const RegionsFM: React.FC<RegionsFMProps> = (props) => {
  var roles: Options[];
  var growth: Options[];
  var contract: Options[];
  var performance: Options[];

  [roles, growth, contract, performance] = setOptions(props.name);

  return (
    <>
      <div className="fm-region-container">
        <h6 className="fm-region-name">{props.name}</h6>
        <div className="fm-role">
          <EmeraldDropdown
            label="Finance Management Role (required)"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChangeFM(
                e,
                value,
                props.context?.Role?.setValue,
                props.save
              );
            }}
            options={roles}
            classes="fm-region-role"
            isValid={true}
          />
        </div>

        {props.context?.Role?.value === "None" ? (
          <div className="GCP-container">
            <EmeraldDropdown
              label="Growth Opportunity (required)"
              outlined
              id="single_select"
              onChange={(e, value) => {
                handleChangeFM(
                  e,
                  value,
                  props.context?.Growth?.setValue,
                  props.save,
                  props.errorContext?.Growth.setValue
                );
              }}
              options={growth}
              isValid={props.errorContext?.Growth.value}
              errorText="This field is required"
            />
            <EmeraldDropdown
              label="Contract Value (required)"
              outlined
              id="single_select"
              onChange={(e, value) => {
                handleChangeFM(
                  e,
                  value,
                  props.context?.Contract?.setValue,
                  props.save,
                  props.errorContext?.Contract.setValue
                );
              }}
              options={contract}
              isValid={props.errorContext?.Contract.value}
              errorText="This field is required"
            />
            <EmeraldDropdown
              label="Performance Risk (required)"
              outlined
              id="single_select"
              onChange={(e, value) => {
                handleChangeFM(
                  e,
                  value,
                  props.context?.Performance?.setValue,
                  props.save,
                  props.errorContext?.Performance.setValue
                );
              }}
              options={performance}
              isValid={props.errorContext?.Performance.value}
              errorText="This field is required"
            />
          </div>
        ) : (
          <></>
        )}
      </div>
    </>
  );
};

export default RegionsFM;
