import React, { useContext, useEffect } from "react";
import { EmeraldInput } from "@emerald-react/input";
import { EmeraldButton } from "@emerald-react/button";

import "../../styles/ClientSetup.scss";
import { MyContext } from "../../context/FMContext";
import { ErrorContext } from "../../context/ErrorContext";

import { EmeraldButtonVariant, EmeraldButtonSize } from "@emerald/nxcore";

interface ClientSetUpProps {
  setDrawer: React.Dispatch<React.SetStateAction<boolean>>;
}

const ClientSetUp: React.FC<ClientSetUpProps> = (props) => {
  const context = useContext(MyContext);
  const errorContext = useContext(ErrorContext);

  if (!context) {
    throw new Error("ClientSetUp must be used within a MyProvider");
  }

  const { ClientName } = context;

  function handleNameChange(
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    ClientName?.setValue(event?.target.value);
  }

  useEffect(() => {
    if (ClientName?.value.trim() === "") {
      errorContext?.clientName.setValue(false);
    } else {
      errorContext?.clientName.setValue(true);
    }
  }, [ClientName?.value]);

  return (
    <>
      <div className="client-setup-container">
        {/* <h6 className="client-setup-title">Client Setup</h6> */}
        <div className="client-name-container">
          <div className="client-name-input-container">
            <EmeraldInput
              label="Client Name (required)"
              outlined
              placeholder="My Client"
              value={ClientName?.value}
              onChange={(event) => {
                handleNameChange(event);
              }}
              isValid={errorContext?.clientName.value}
              errorText="This field is Required"
            />
          </div>
          <EmeraldButton
            icon="error"
            label="Review Disclaimer"
            className="customInfoBtn"
            size={EmeraldButtonSize.Medium}
            onClick={() => props.setDrawer(true)}
            type={EmeraldButtonVariant.TextButton}
          />
        </div>
      </div>
    </>
  );
};

export default ClientSetUp;
