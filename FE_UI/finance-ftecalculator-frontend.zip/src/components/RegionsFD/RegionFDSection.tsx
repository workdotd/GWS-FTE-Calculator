import React, { useContext } from "react";

import { EmeraldDropdown } from "@emerald-react/dropdown";
import { EmeraldRadio } from "@emerald-react/radio";

import {
  FrequencyValues,
  getDeliveryModelOptions,
  getFrequencyOptions,
} from "../../data/Frequency";
import { Sections } from "./FDdropdowns";
import { MyContext, RegionFDType } from "../../context/FMContext";
import {
  getRegion,
  getLocations,
  getSaveFD,
  changeSave,
} from "../../utils/GetValues";
import { Options } from "../../data/Options";

interface RegionFDSectionProps {
  element: Sections;
}

const RegionFDSection: React.FC<RegionFDSectionProps> = ({ element }) => {
  const context = useContext(MyContext);
  var region: RegionFDType | undefined;
  var locations: Options[];
  var index = 0;

  region = getRegion(context);
  locations = getLocations(context);

  const handleChange = (
    e: any,
    value: unknown,
    label: string,
    region: RegionFDType | undefined
  ) => {
    if (region && value) {
      const inputValue = value; // Assert that value is of type ValueType[]

      switch (label) {
        // AR/AP
        case "Billing":
          region.ARAP.Billing.setValue(inputValue[0]);
          break;
        case "Fund Reconciliations":
          region.ARAP.FundRecon.setValue(inputValue[0]);
          break;
        case "Payment":
          region.ARAP.Payment.setValue(inputValue[0]);
          break;

        // CBRE Reporting
        case "Monthly JDE period close and Open PO review":
          region.CBREReport.OpenPOReview.setValue(inputValue[0]);
          break;
        case "Monthly JDE Balance Sheet Reconciliation":
          region.CBREReport.BalanceSheetRecon.setValue(inputValue[0]);
          break;
        case "Corporate Month End Revenue/Costs Adjustments":
          region.CBREReport.MER.setValue(inputValue[0]);
          break;
        case "Corporate Pass Through Reconciliation":
          region.CBREReport.PTR.setValue(inputValue[0]);
          break;
        case "Corporate Payment Entries Submission":
          region.CBREReport.PES.setValue(inputValue[0]);
          break;
        case "Internal & External Audit Sampling Requests (SOC1 & SOX)":
          region.CBREReport.ASR.setValue(inputValue[0]);
          break;
        case "Corporate P&L Month End Review, Analysis & Queries":
          region.CBREReport.MERAQ.setValue(inputValue[0]);
          break;
        case "Corporate Yearly Budget - Preparation, Review & Approval":
          region.CBREReport.PRA.setValue(inputValue[0]);
          break;
        case "Corporate Monthly Forecast - Preparation, Review & Approval":
          region.CBREReport.MEA.setValue(inputValue[0]);
          break;
        case "Corporate Operation Merit & Bonus Review":
          region.CBREReport.OMBR.setValue(inputValue[0]);
          break;

        // Client Reporting
        case "Client Month End Accruals - Open PO, Rental, Utilities etc.- Manual Journal Entries Posting":
          region.ClientReport.MEA.setValue(inputValue[0]);
          break;
        case "Monthly Operational Call for Client Month End Close (Queries from FM - Finance Related)":
          region.ClientReport.MOC.setValue(inputValue[0]);
          break;
        case "Client Budget - Management Fee & Payroll Calculation; Vendor Spend Data":
          region.ClientReport.CB.setValue(inputValue[0]);
          break;
        case "Client Forecast - Vendor Spend":
          region.ClientReport.CF.setValue(inputValue[0]);
          break;
        case "Client Savings Report":
          region.ClientReport.CSR.setValue(inputValue[0]);
          break;
        case "Client Finance Audit Support":
          region.ClientReport.CFAS.setValue(inputValue[0]);
          break;
        case "Client Billing to Actuals Reconciliation":
          region.ClientReport.CBAR.setValue(inputValue[0]);
          break;
        case "Report Freq":
          region.ClientReport.Report_Freq.setValue(inputValue[0]);
          break;
        case "Report Type": // Special handling for report type
          region.ClientReport.ReportType.setValue(inputValue[0]);
          break;
        case "Select Delivery Model (required)":
          region.DeliveryModel.setValue(inputValue[0]);
          break;
        default:
          return Error("No matching label");
      }
      if (getSaveFD(context)) {
        changeSave(context, false);
      }
    } else {
      throw new Error("Type Error: Passed undefined");
    }
  };

  const handleFreqOptionChange = (
    label: string,
    region: RegionFDType | undefined
  ) => {
    if (region) {
      var option: Options[];

      switch (label) {
        // AR/AP
        case "Billing":
          option = getFrequencyOptions(region.ARAP.Billing.value);
          break;
        case "Fund Reconciliations":
          option = getFrequencyOptions(region.ARAP.FundRecon.value);
          break;
        case "Payment":
          option = getFrequencyOptions(region.ARAP.Payment.value);
          break;

        // CBRE Reporting
        case "Monthly JDE period close and Open PO review":
          option = getFrequencyOptions(region.CBREReport.OpenPOReview.value);
          break;
        case "Monthly JDE Balance Sheet Reconciliation":
          option = getFrequencyOptions(
            region.CBREReport.BalanceSheetRecon.value
          );
          break;
        case "Corporate Month End Revenue/Costs Adjustments":
          option = getFrequencyOptions(region.CBREReport.MER.value);
          break;
        case "Corporate Pass Through Reconciliation":
          option = getFrequencyOptions(region.CBREReport.PTR.value);
          break;
        case "Corporate Payment Entries Submission":
          option = getFrequencyOptions(region.CBREReport.PES.value);
          break;
        case "Internal & External Audit Sampling Requests (SOC1 & SOX)":
          option = getFrequencyOptions(region.CBREReport.ASR.value);
          break;
        case "Corporate P&L Month End Review, Analysis & Queries":
          option = getFrequencyOptions(region.CBREReport.MERAQ.value);
          break;
        case "Corporate Yearly Budget - Preparation, Review & Approval":
          option = getFrequencyOptions(region.CBREReport.PRA.value);
          break;
        case "Corporate Monthly Forecast - Preparation, Review & Approval":
          option = getFrequencyOptions(region.CBREReport.MEA.value);
          break;
        case "Corporate Operation Merit & Bonus Review":
          option = getFrequencyOptions(region.CBREReport.OMBR.value);
          break;

        // Client Reporting
        case "Client Month End Accruals - Open PO, Rental, Utilities etc.- Manual Journal Entries Posting":
          option = getFrequencyOptions(region.ClientReport.MEA.value);
          break;
        case "Monthly Operational Call for Client Month End Close (Queries from FM - Finance Related)":
          option = getFrequencyOptions(region.ClientReport.MOC.value);
          break;
        case "Client Budget - Management Fee & Payroll Calculation; Vendor Spend Data":
          option = getFrequencyOptions(region.ClientReport.CB.value);
          break;
        case "Client Forecast - Vendor Spend":
          option = getFrequencyOptions(region.ClientReport.CF.value);
          break;
        case "Client Savings Report":
          option = getFrequencyOptions(region.ClientReport.CSR.value);
          break;
        case "Client Finance Audit Support":
          option = getFrequencyOptions(region.ClientReport.CFAS.value);
          break;
        case "Client Billing to Actuals Reconciliation":
          option = getFrequencyOptions(region.ClientReport.CBAR.value);
          break;
        case "Report Freq":
          option = getFrequencyOptions(region.ClientReport.Report_Freq.value);
          break;
        default:
          option = FrequencyValues;
      }
      return option;
    } else {
      return FrequencyValues;
    }
  };

  const handleRadioChange = (
    e: any,
    value: unknown,
    label: string,
    region: RegionFDType | undefined
  ) => {
    if (typeof value === "string") {
      if (label === "Report Type") {
        region?.ClientReport.ReportType.setValue(value);
      }
      if (getSaveFD(context)) {
        changeSave(context, false);
      }
    }
  };

  return (
    <>
      <div className="fd-section">
        <div className="fd-section-inputs">
          {element.dropdowns.map((ele, j) => {
            if (ele.label !== "Report Type") index++;
            return (
              <>
                {element.section_title === "Delivery Model" ? (
                  <EmeraldDropdown
                    key={j}
                    label={ele.label}
                    outlined
                    id="single_select"
                    onChange={(e, val) => {
                      handleChange(e, val, ele.label, region);
                    }}
                    options={getDeliveryModelOptions(
                      region?.DeliveryModel.value
                    )}
                  />
                ) : ele.label === "Report Type" ? (
                  <>
                    <div className="horizontal">
                      <EmeraldRadio
                        label="Standard Report"
                        value="Standard Report"
                        checked={
                          region?.ClientReport.ReportType.value ===
                          "Standard Report"
                            ? true
                            : false
                        }
                        onChange={(value, _name, e) =>
                          handleRadioChange(e, value, ele.label, region)
                        }
                      />
                      <EmeraldRadio
                        label="Customised Report"
                        value="Customised Report"
                        checked={
                          region?.ClientReport.ReportType.value ===
                          "Customised Report"
                            ? true
                            : false
                        }
                        onChange={(value, _name, e) =>
                          handleRadioChange(e, value, ele.label, region)
                        }
                      />
                    </div>
                  </>
                ) : (
                  <EmeraldDropdown
                    key={j}
                    label={
                      ele.label === "Report Freq"
                        ? index + ". " + region?.ClientReport.ReportType.value
                        : index + ". " + ele.label
                    }
                    outlined
                    id="single_select"
                    onChange={(e, val) => {
                      handleChange(e, val, ele.label, region);
                    }}
                    options={handleFreqOptionChange(ele.label, region)}
                  />
                )}
              </>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default RegionFDSection;
