import React, { useContext } from "react";

import { EmeraldDropdown } from "@emerald-react/dropdown";
import { ContractVariablesType, MyContext } from "../../context/FMContext";
import {
  changeSave,
  getContractVariables,
  getSaveFD,
} from "../../utils/GetValues";
import {
  getAutomationValues,
  getBankValues,
  getCRLValues,
  getContractStructureValues,
  getPrincipalMAValues,
  getSpendRatioValues,
  getTechStackValues,
} from "../../data/ContractVariablesOptions";

const ContractVariables: React.FC = () => {
  const context = useContext(MyContext);
  var ContractVariables: ContractVariablesType | undefined;

  ContractVariables = getContractVariables(context);

  const handleChange = (
    e: any,
    value: unknown,
    changeState: React.Dispatch<React.SetStateAction<string>> | undefined
  ) => {
    if (changeState && value) {
      const inputValue = value; // Assert that value is of type ValueType[]

      if (typeof inputValue === "string") {
        changeState(inputValue);
      } else if (typeof inputValue === "object") {
        changeState(inputValue[0]);
      }

      if (getSaveFD(context)) {
        changeSave(context, false);
      }
    } else {
      throw new Error("Type Error: Passed undefined");
    }
  };

  return (
    <>
      <div className="fd-section">
        <div className="fd-section-inputs">
          <EmeraldDropdown
            label="1. Contract Structure"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.Structure.setValue);
            }}
            options={getContractStructureValues(
              ContractVariables?.Structure.value
            )}
          />

          <EmeraldDropdown
            label="2. Spend Ratio"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.SpendRatio.setValue);
            }}
            options={getSpendRatioValues(ContractVariables?.SpendRatio.value)}
          />

          <EmeraldDropdown
            label="3. Principal/MA"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.Principal.setValue);
            }}
            options={getPrincipalMAValues(ContractVariables?.Principal.value)}
          />

          <EmeraldDropdown
            label="4. Client Reporting Level"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.CRL.setValue);
            }}
            options={getCRLValues(ContractVariables?.CRL.value)}
          />
          <EmeraldDropdown
            label="5. Tech Stack"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.TechStack.setValue);
            }}
            options={getTechStackValues(ContractVariables?.TechStack.value)}
          />

          <EmeraldDropdown
            label="6. Automation Adjustment"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.AutomationAdj.setValue);
            }}
            options={getAutomationValues(
              ContractVariables?.AutomationAdj.value
            )}
          />

          <EmeraldDropdown
            label="7. Bank Account"
            outlined
            id="single_select"
            onChange={(e, value) => {
              handleChange(e, value, ContractVariables?.BankAccount.setValue);
            }}
            options={getBankValues(ContractVariables?.BankAccount.value)}
          />
        </div>
      </div>
    </>
  );
};

export default ContractVariables;
