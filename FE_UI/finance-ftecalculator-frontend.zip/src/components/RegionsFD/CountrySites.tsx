import React, { useContext, useEffect, useState } from "react";
import { MyContext, RegionFDType } from "../../context/FMContext";
import {
  getSaveFD,
  changeSave,
  getLocations,
  getRegion,
  getRegionFDError,
} from "../../utils/GetValues";
import { ErrorContext, RegionFDErrorType } from "../../context/ErrorContext";
import { Options } from "../../data/Options";

import { EmeraldDropdown } from "@emerald-react/dropdown";
import { EmeraldInput } from "@emerald-react/input";

interface CountrySitesProps {}

const CountrySites: React.FC<CountrySitesProps> = (props) => {
  const context = useContext(MyContext);
  const errorContext = useContext(ErrorContext);

  var region: RegionFDType | undefined;
  var regionError: RegionFDErrorType | undefined;
  var locations: Options[];

  region = getRegion(context);
  regionError = getRegionFDError(context, errorContext);
  locations = getLocations(context);

  const handleNumInputChange = (
    e: any,
    value: number,
    region: RegionFDType | undefined
  ) => {
    if (e.target.value !== "") {
      const inputValue = e.target.value;
      const numericValue = inputValue.replace(/[^0-9]/g, "");

      e.target.value = Number(numericValue);

      region?.Spend.setValue(numericValue ? Number(numericValue) : 0);
      regionError?.Spend.setValue(true);
    } else {
      region?.Spend.setValue(0);
    }

    if (getSaveFD(context)) {
      changeSave(context, false);
    }
  };

  const handleCountriesChange = (
    e: any,
    value: unknown,
    region: RegionFDType | undefined,
    saved?: boolean | false
  ) => {
    if (value && region?.Country_Sites.value) {
      const newMap = new Map();

      var length = 0;
      for (var idx in value) {
        if (value[idx] !== "None") {
          length++;
          if (region.Country_Sites.value.has(value[idx])) {
            newMap.set(value[idx], region.Country_Sites.value.get(value[idx]));
          } else {
            newMap.set(value[idx], 0);
          }
        } else {
          locations[0].selected = false;
        }
      }

      if (length) {
        locations[0].selected = false;
      } else {
        locations[0].selected = true;
      }
      // console.log(locations);
      region?.Country_Sites?.setValue(newMap);
      regionError?.Country.setValue(true);
      // console.log(newMap)
      if (getSaveFD(context) && !saved) {
        changeSave(context, false);
      }
    }
  };

  const handleSitesChange = (
    e: any,
    key: string,
    region: RegionFDType | undefined
  ) => {
    if (e.target.value !== "") {
      const newMap = new Map(region?.Country_Sites.value);

      const inputValue = e.target.value;
      const numericValue = inputValue.replace(/[^0-9]/g, "");

      newMap.set(key, numericValue ? Number(numericValue) : 0);
      region?.Country_Sites?.setValue(newMap);
      regionError?.Sites.setValue(true);
    } else {
      region?.Country_Sites.value.set(key, 0);
    }

    if (getSaveFD(context)) {
      changeSave(context, false);
    }
  };

  const handleRegex = (e: any) => {
    const inputValue = (e.target as HTMLInputElement).value;
    const numericValue = inputValue.replace(/[^0-9]/g, "");
    (e.target as HTMLInputElement).value = numericValue;
  };

  useEffect(() => {
    if (region?.Country_Sites?.value instanceof Map) {
      const keysArray = Array.from(region.Country_Sites.value.keys());
      const saved = getSaveFD(context);
      handleCountriesChange(null, keysArray, region, saved);
    } else {
      console.log("Value is not a Map");
    }
  }, [context?.FinanceDelivery?.FDRegion?.value]);

  return (
    <>
      <div className="fd-section">
        <div className="fd-section-inputs fd-region-container-top">
          <EmeraldInput
            label="Total Managed Spend in USD (required)"
            outlined
            type="number"
            id="single_select"
            value={region?.Spend.value}
            leadingIcon="paid"
            onChange={(e: any, val: number) => {
              handleNumInputChange(e, val, region);
            }}
            onKeyDown={handleRegex}
            isValid={regionError?.Spend.value}
            errorText={
              region?.Spend.value
                ? "Spend cannot be more than 2,147,483,647."
                : "This field cannot be zero"
            }
          />

          <EmeraldDropdown
            label="Select Countries"
            outlined
            multiSelect
            onChange={(e, val) => {
              handleCountriesChange(e, val, region);
            }}
            options={locations}
            isValid={regionError?.Country.value}
            errorText="This is a required field"
          />

          {region?.Country_Sites?.value &&
            Array.from(region?.Country_Sites?.value.entries()).map(
              ([key, _value]) =>
                key && (
                  <EmeraldInput
                    label={"Number of Sites for " + key}
                    outlined
                    type="number"
                    id="single_select"
                    value={region?.Country_Sites?.value.get(key)}
                    onChange={(e: any, val: any) => {
                      handleSitesChange(e, key, region);
                    }}
                    onKeyUp={handleRegex}
                    isValid={regionError?.Sites.value}
                    errorText="This field cannot be zero"
                    onKeyDown={() => {}}
                  />
                )
            )}
        </div>
      </div>
    </>
  );
};

export default CountrySites;
