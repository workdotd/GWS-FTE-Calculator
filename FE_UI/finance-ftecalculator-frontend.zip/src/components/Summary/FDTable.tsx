import React, { useContext } from "react";
import { MyContext } from "../../context/FMContext";

import { EmeraldDataTable } from "@emerald-react/data-table";
import CellData from "./Cell";
import { getRegionSummary } from "../../utils/GetValues";

const FDTable: React.FC = () => {
  const context = useContext(MyContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  const response = getRegionSummary(context);
  const RB = response?.RB;
  const ML = response?.ML;

  return (
    <>
      <div className="fd-summary">
        <div>
          <h3>{context.FinanceDelivery?.FDRegion?.value}</h3>
          <EmeraldDataTable
            allowResizeColumns={false}
            columnDefs={[
              {
                field: "Index",
                headerName: "",
                cellTemplate: (
                  _row: any,
                  _col: any,
                  obj: { value: string | number | undefined }
                ) => <CellData value={obj.value} column={_col} />,
              },
              {
                field: "Delivery Models/Roles",
                headerName: "Delivery Model/Roles",
                cellTemplate: (
                  _row: any,
                  _col: any,
                  obj: { value: string | number | undefined }
                ) => <CellData value={obj.value} />,
              },
              {
                field: "Location",
                headerName: "Location",
                cellTemplate: (
                  _row: any,
                  _col: any,
                  obj: { value: string | number | undefined }
                ) => <CellData value={obj.value} />,
              },
              {
                field: "FTE",
                headerName: "FTE",
                cellTemplate: (
                  _row: any,
                  _col: any,
                  obj: { value: string | number | undefined }
                ) => <CellData value={obj.value} />,
              },
            ]}
            rowData={[
              {
                Index: "Rule Based",
                "Delivery Models/Roles": "On-Site",
                Location: "",
                FTE: "",
              },
              {
                Index: "",
                "Delivery Models/Roles": "Finance Analyst",
                Location: "",
                FTE: RB?.FA.value,
              },
              {
                Index: "",
                "Delivery Models/Roles": "Sr. Finance Analyst",
                Location: "",
                FTE: RB?.SFA.value,
              },
              {
                Index: "",
                "Delivery Models/Roles": "Finance Manager",
                Location: "",
                FTE: RB?.FM.value,
              },
              {
                Index: "Total Financial Delivery (Rule Based)",
                FTE: RB?.TotalFTE.value,
              },
            ]}
          />
        </div>

        <EmeraldDataTable
          allowResizeColumns={false}
          columnDefs={[
            {
              field: "Index",
              headerName: "",
              cellTemplate: (
                _row: any,
                _col: any,
                obj: { value: string | number | undefined }
              ) => <CellData value={obj.value} />,
            },
            {
              field: "Delivery Models/Roles",
              headerName: "Delivery Model/Roles",
              cellTemplate: (
                _row: any,
                _col: any,
                obj: { value: string | number | undefined }
              ) => <CellData value={obj.value} />,
            },
            {
              field: "Location",
              headerName: "Location",
              cellTemplate: (
                _row: any,
                _col: any,
                obj: { value: string | number | undefined }
              ) => <CellData value={obj.value} />,
            },
            {
              field: "FTE",
              headerName: "FTE",
              cellTemplate: (
                _row: any,
                _col: any,
                obj: { value: string | number | undefined }
              ) => <CellData value={obj.value} />,
            },
          ]}
          rowData={[
            {
              Index: "ML Based",
              "Delivery Models/Roles": "On-Site",
              Location: "",
              FTE: "",
            },

            {
              Index: "",
              "Delivery Models/Roles": "Finance Analyst",
              Location: "",
              FTE: ML?.FA.value,
            },
            {
              Index: "",
              "Delivery Models/Roles": "Sr. Finance Analyst",
              Location: "",
              FTE: ML?.SFA.value,
            },
            {
              Index: "",
              "Delivery Models/Roles": "Finance Manager",
              Location: "",
              FTE: ML?.FM.value,
            },
            {
              Index: "Total Financial Delivery (ML Based)",
              FTE: ML?.TotalFTE.value,
            },
          ]}
        />
      </div>
    </>
  );
};

export default FDTable;
