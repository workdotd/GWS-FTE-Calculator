import React, { useContext } from "react";
import { MyContext } from "../../context/FMContext";

import { EmeraldDataTable } from "@emerald-react/data-table";
import CellData from "./Cell";

const FMTable: React.FC = () => {
  const context = useContext(MyContext);

  if (!context) {
    throw new Error("Component must be used within a MyProvider");
  }

  const AMERICAS = context.FinanceManagement?.RegionalAssessment?.AMERICAS;
  const EMEA = context.FinanceManagement?.RegionalAssessment?.EMEA;
  const APAC = context.FinanceManagement?.RegionalAssessment?.APAC;
  const Global = context.FinanceManagement?.GlobalAssessment;

  const AMSResponse = context.FMResponse.AMERICAS;
  const EMEAResponse = context.FMResponse.EMEA;
  const APACResponse = context.FMResponse.APAC;
  const GlobalResponse = context.FMResponse.Global;

  return (
    <>
      <EmeraldDataTable
        allowResizeColumns={false}
        columnDefs={[
          {
            field: "Index",
            headerName: "",
            cellTemplate: (
              _row: any,
              col: any,
              obj: { value: string | number | undefined }
            ) => <CellData value={obj.value} column={col} />,
          },
          {
            field: "Regional Code",
            headerName: "Regional Code",
            cellTemplate: (
              _row: any,
              _col: any,
              obj: { value: string | number | undefined }
            ) => <CellData value={obj.value} />,
          },
          {
            field: "Location",
            headerName: "Location",
            cellTemplate: (
              _row: any,
              _col: any,
              obj: { value: string | number | undefined }
            ) => <CellData value={obj.value} />,
          },
          {
            field: "FTE",
            headerName: "FTE",
            cellTemplate: (
              _row: any,
              _col: any,
              obj: { value: string | number | undefined }
            ) => <CellData value={obj.value} />,
          },
        ]}
        rowData={[
          {
            Index: "Global Roles",
            "Regional Code": GlobalResponse?.Role?.value,
            Location: Global?.Location?.value,
            FTE: GlobalResponse?.FTE?.value,
          },
          {
            Index: "Regional Roles",
            "Regional Code": "--",
            Location: "--",
            FTE: "--",
          },
          {
            Index: "AMERICAS",
            "Regional Code": AMSResponse?.Role?.value,
            Location: AMERICAS?.Location?.value,
            FTE: AMSResponse?.FTE?.value,
          },
          {
            Index: "EMEA",
            "Regional Code": EMEAResponse?.Role?.value,
            Location: EMEA?.Location?.value,
            FTE: EMEAResponse?.FTE?.value,
          },
          {
            Index: "APAC",
            "Regional Code": APACResponse?.Role?.value,
            Location: APAC?.Location?.value,
            FTE: APACResponse.FTE.value,
          },
          {
            Index: "Total Finance Management",
            FTE: context.FMResponse?.TotalFM?.value,
          },
        ]}
      />
    </>
  );
};

export default FMTable;
