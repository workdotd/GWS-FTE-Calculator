import React from 'react';
import "../../styles/Drawer.scss";

const Drawer: React.FC = () => {
  return (
    <>
        <div className="drawer-section">
            <p>This finance FTE calculator is not a substitute for actual solutioning. The best practice is still to solution and put forward a finance team based on a detailed understanding of client requirements and performance expectation.</p>
            <p>This calculator provides 2 key advantages: </p>
            <p>(1) It calculates a data-driven “base model” finance team that the solution team can refine further or build on according to client requirements. </p>
            <p>(2) It provides an intelligent benchmark against which a solution or price can be measured and evaluated.</p>
            <p>Artificial intelligence or machine learning used in this tool does not replace valuable human critical thinking and solutioning. AI used in this tool is meant to augment human intelligence and productivity by increasing efficiency and accuracy in the solutioning process.</p>
        </div>
    </>
  );
};

export default Drawer;
