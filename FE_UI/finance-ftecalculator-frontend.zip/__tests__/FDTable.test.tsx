import React from "react";
import { render, screen } from "@testing-library/react";
import { mockContext } from "../__mocks__/mockContext";
import FDTable from "../src/components/Summary/FDTable";
import { MyContext } from "../src/context/FMContext";
import { getRegionSummary } from "../src/utils/GetValues";

jest.mock("../src/utils/GetValues", () => ({
  getRegionSummary: jest.fn(),
}));

describe("FDTable Component", () => {
  beforeEach(() => {
    // Reset mock implementation before each test
    (getRegionSummary as jest.Mock).mockReturnValue(
      mockContext.FDResponse.AMERICAS
    );
  });

  it("renders tables with correct data when context is provided", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <FDTable />
      </MyContext.Provider>
    );

    // Check Rule Based table values
    expect(screen.getByText("Rule Based")).toBeInTheDocument();
    expect(screen.getByText("100")).toBeInTheDocument(); // FTE for Finance Analyst
    expect(screen.getByText("50")).toBeInTheDocument(); // FTE for Sr. Finance Analyst
    expect(screen.getByText("20")).toBeInTheDocument(); // FTE for Finance Manager
    expect(
      screen.getByText("Total Financial Delivery (Rule Based)")
    ).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument(); // Total FTE

    // Check ML Based table values
    expect(screen.getByText("ML Based")).toBeInTheDocument();
    expect(screen.getByText("80")).toBeInTheDocument(); // FTE for Finance Analyst in ML
    expect(screen.getByText("40")).toBeInTheDocument(); // FTE for Sr. Finance Analyst in ML
    expect(screen.getByText("15")).toBeInTheDocument(); // FTE for Finance Manager in ML
    expect(
      screen.getByText("Total Financial Delivery (ML Based)")
    ).toBeInTheDocument();
    expect(screen.getByText("1.5")).toBeInTheDocument(); // Total FTE in ML
  });

  it("throws an error when context is not provided", () => {
    // We expect an error to be thrown when context is not provided
    expect(() => render(<FDTable />)).toThrow(
      "FinanceManagement must be used within a MyProvider"
    );
  });
});
