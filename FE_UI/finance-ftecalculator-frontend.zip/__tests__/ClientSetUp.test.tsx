// ClientSetUp.test.tsx
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import ClientSetUp from "../src/components/ClientSetUp/ClientSetUp"; // Adjust the import path as necessary
import { MyContext } from "../src/context/FMContext";
import { ErrorContext } from "../src/context/ErrorContext";
import { mockContext, mockErrorContext } from "../__mocks__/mockContext";

const renderWithContext = (ui: React.ReactElement) => {
  return render(
    <MyContext.Provider value={mockContext}>
      <ErrorContext.Provider value={mockErrorContext}>
        {ui}
      </ErrorContext.Provider>
    </MyContext.Provider>
  );
};

describe("ClientSetUp Component", () => {
  test("renders ClientSetUp with input and button", () => {
    renderWithContext(<ClientSetUp setDrawer={jest.fn()} />);

    // Check if the input field is rendered
    const inputElement = screen.getByLabelText(/Client Name \(required\)/i);
    expect(inputElement).toBeInTheDocument();

    // Check if the button is rendered
    const buttonElement = screen.getByRole("button", {
      name: /Review Disclaimer/i,
    });
    expect(buttonElement).toBeInTheDocument();
  });

  test("updates client name on input change", () => {
    renderWithContext(<ClientSetUp setDrawer={jest.fn()} />);

    const inputElement = screen.getByLabelText(/Client Name \(required\)/i);

    // Simulate changing the input value
    fireEvent.change(inputElement, { target: { value: "New Client" } });

    // Check if setValue was called with the new value
    expect(mockContext.ClientName?.setValue).toHaveBeenCalledWith("New Client");
  });

  test("sets error context when input is empty", () => {
    renderWithContext(<ClientSetUp setDrawer={jest.fn()} />);

    const inputElement = screen.getByLabelText(/Client Name \(required\)/i);

    // Simulate changing to empty value
    fireEvent.change(inputElement, { target: { value: "" } });

    // Check if error context's setValue was called
    expect(mockErrorContext.clientName.setValue).toHaveBeenCalledWith(true);
  });

  test("calls setDrawer when button is clicked", () => {
    const setDrawerMock = jest.fn();

    renderWithContext(<ClientSetUp setDrawer={setDrawerMock} />);

    const buttonElement = screen.getByRole("button", {
      name: /Review Disclaimer/i,
    });

    // Simulate button click
    fireEvent.click(buttonElement);

    // Check if setDrawer was called
    expect(setDrawerMock).toHaveBeenCalledWith(true);
  });
});
