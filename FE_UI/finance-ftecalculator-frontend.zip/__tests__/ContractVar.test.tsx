import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ContractVariables from "../src/components/RegionsFD/ContractVariables"; // Adjust import path if necessary
import { MyContext } from "../src/context/FMContext"; // Adjust import path if necessary
import { mockContext } from "../__mocks__/mockContext";

describe("ContractVariables Component", () => {
  beforeEach(() => {
    render(
      <MyContext.Provider value={mockContext}>
        <ContractVariables />
      </MyContext.Provider>
    );

    screen.debug();
  });

  test("renders all dropdowns", () => {
    expect(
      screen.getAllByLabelText(/1. Contract Structure/i)[0]
    ).toBeInTheDocument();
    expect(screen.getAllByLabelText(/2. Spend Ratio/i)[0]).toBeInTheDocument();
    expect(
      screen.getAllByLabelText(/3. Principal\/MA/i)[0]
    ).toBeInTheDocument();
    expect(
      screen.getAllByLabelText(/4. Client Reporting Level/i)[0]
    ).toBeInTheDocument();
    expect(screen.getAllByLabelText(/5. Tech Stack/i)[0]).toBeInTheDocument();
    expect(
      screen.getAllByLabelText(/6. Automation Adjustment/i)[0]
    ).toBeInTheDocument();
    expect(screen.getAllByLabelText(/7. Bank Account/i)[0]).toBeInTheDocument();
  });

  // test("handles change in Contract Structure dropdown", () => {
  //   const structureDropdown = screen.getAllByLabelText(
  //     /1. Contract Structure/i
  //   );

  //   expect(structureDropdown[0]).toBeInTheDocument();
  //   userEvent.selectOptions(structureDropdown[0], "Cost Plus");

  //   // expect(
  //   //   mockContext.FinanceDelivery?.AMERICAS?.ContractVariables.Structure
  //   //     .setValue
  //   // ).toHaveBeenCalledWith("GMP");
  // });

  //   test("handles change in Spend Ratio dropdown", () => {
  //     const spendRatioDropdown = screen.getByLabelText(/2. Spend Ratio/i);

  //     fireEvent.change(spendRatioDropdown, { target: { value: "50%" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("50%");
  //   });

  //   test("handles change in Principal/MA dropdown", () => {
  //     const principalDropdown = screen.getByLabelText(/3. Principal\/MA/i);

  //     fireEvent.change(principalDropdown, { target: { value: "Principal A" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("Principal A");
  //   });

  //   test("handles change in Client Reporting Level dropdown", () => {
  //     const crlDropdown = screen.getByLabelText(/4. Client Reporting Level/i);

  //     fireEvent.change(crlDropdown, { target: { value: "Level 1" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("Level 1");
  //   });

  //   test("handles change in Tech Stack dropdown", () => {
  //     const techStackDropdown = screen.getByLabelText(/5. Tech Stack/i);

  //     fireEvent.change(techStackDropdown, { target: { value: "Tech Stack A" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("Tech Stack A");
  //   });

  //   test("handles change in Automation Adjustment dropdown", () => {
  //     const automationDropdown = screen.getByLabelText(/6. Automation Adjustment/i);

  //     fireEvent.change(automationDropdown, { target: { value: "Adjustment A" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("Adjustment A");
  //   });

  //   test("handles change in Bank Account dropdown", () => {
  //     const bankAccountDropdown = screen.getByLabelText(/7. Bank Account/i);

  //     fireEvent.change(bankAccountDropdown, { target: { value: "Bank A" } });

  //     expect(mockSetValue).toHaveBeenCalledWith("Bank A");
  //   });
});
