// FinanceDelivery.test.tsx

import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { MyContext } from "../src/context/FMContext";
import { mockContext } from "../__mocks__/mockContext";
import FinanceDelivery from "../src/components/FinanceDelivery/FinanceDelivery"; // Adjust import path as necessary

describe("FinanceDelivery Component", () => {
  const scrollToTopMock = jest.fn();
  const scrollableRefMock = React.createRef<HTMLDivElement>();

  beforeEach(() => {
    jest.clearAllMocks(); // Clear any previous mock calls
  });

  it("renders correctly and displays active region", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <FinanceDelivery
          scrollableRef={scrollableRefMock}
          scrollToTop={scrollToTopMock}
        />
      </MyContext.Provider>
    );

    // Check if regions are rendered correctly
    expect(screen.getByText("AMERICAS")).toBeInTheDocument();
    expect(screen.getByText("EMEA")).toBeInTheDocument();
    expect(screen.getByText("APAC")).toBeInTheDocument();

    // Check if the active class is applied to the AMERICAS region
    expect(screen.getByText("AMERICAS")).toHaveClass("active");
  });

  it("changes region and calls scrollToTop", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <FinanceDelivery
          scrollableRef={scrollableRefMock}
          scrollToTop={scrollToTopMock}
        />
      </MyContext.Provider>
    );

    // Click on EMEA region
    fireEvent.click(screen.getByText("EMEA"));

    // Check if setValue was called with correct argument
    expect(
      mockContext.FinanceDelivery?.FDRegion?.setValue
    ).toHaveBeenCalledWith("EMEA");

    // Check if scrollToTop was called
    expect(scrollToTopMock).toHaveBeenCalled();
  });

  it("changes region and updates active class", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <FinanceDelivery
          scrollableRef={scrollableRefMock}
          scrollToTop={scrollToTopMock}
        />
      </MyContext.Provider>
    );

    // Click on EMEA region
    fireEvent.click(screen.getByText("EMEA"));

    // Verify that setValue was called with 'EMEA'
    expect(
      mockContext.FinanceDelivery?.FDRegion?.setValue
    ).toHaveBeenCalledWith("EMEA");

    // Re-render to check if active class updates (simulating a state change)
    render(
      <MyContext.Provider
        value={{
          ...mockContext,
          FinanceDelivery: {
            ...mockContext.FinanceDelivery,
            FDRegion: {
              value: "EMEA", // Update the value to simulate state change
              setValue: jest.fn(),
            },
          },
        }}
      >
        <FinanceDelivery
          scrollableRef={scrollableRefMock}
          scrollToTop={scrollToTopMock}
        />
      </MyContext.Provider>
    );

    // Check if EMEA is now active
    const emeaElements = screen.getAllByText("EMEA");
    expect(emeaElements[1]).toHaveClass("active");
  });
});
