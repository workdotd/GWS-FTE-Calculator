// GlobalHeader.test.tsx
import { render, screen } from '@testing-library/react';
import GlobalHeader from '../src/components/GlobalHeader/GlobalHeader'; // Adjust the path as necessary
import React from 'react';

describe('GlobalHeader Component', () => {
  test('renders GlobalHeader with logo and title', () => {
    render(<GlobalHeader />);
    
    // Check if the logo is rendered
    const logoElement = screen.getByAltText(/logo/i);
    expect(logoElement).toBeInTheDocument();
    
    // Check if the title text is rendered correctly
    const titleElement = screen.getByText(/GWS Enterprise Finance/i);
    expect(titleElement).toBeInTheDocument();
  });

  test('renders header container', () => {
    render(<GlobalHeader />);
    
    // Check if the header container is rendered
    const containerElement = screen.getByRole('heading', { level: 6 });
    expect(containerElement).toBeInTheDocument();
  });
});