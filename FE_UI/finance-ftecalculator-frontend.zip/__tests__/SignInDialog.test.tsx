import { render, screen } from "@testing-library/react";
import { SignInDialog } from "../src/views/SignInDialog/SignInDialog";

test("renders Sign In Dialog", () => {
  render(<SignInDialog />);
  const signInDialog = screen.getByText(/CBRE/);
  expect(signInDialog).toBeInTheDocument();
});
