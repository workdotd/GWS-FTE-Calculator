import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import CountrySites from "../src/components/RegionsFD/CountrySites"; // Adjust import path if necessary
import { Options } from "../src/data/Options";
import { mockContext, mockErrorContext } from "../__mocks__/mockContext";
import { MyContext } from "../src/context/FMContext";
import { ErrorContext } from "../src/context/ErrorContext";

// const mockContextValue = {
//   getSaveFD: jest.fn().mockReturnValue(false),
//   changeSave: jest.fn(),
//   getRegion: jest.fn().mockReturnValue(mock),
//   getLocations: jest.fn().mockReturnValue([{ label: "USA", value: "USA", selected: false }]),
//   getRegionFDError: jest.fn().mockReturnValue(m),
// };

describe("CountrySites Component", () => {
  beforeEach(() => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <CountrySites />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );
  });

  test("renders Total Managed Spend input", () => {
    const spendInput = screen.getAllByLabelText(/Total Managed Spend in USD/i);
    expect(spendInput[0]).toBeInTheDocument();
    expect(spendInput[0]).toHaveValue(500000);
  });

  test("updates Total Managed Spend correctly", () => {
    const spendInput = screen.getAllByLabelText(/Total Managed Spend in USD/i);
    fireEvent.change(spendInput[0], { target: { value: "2000" } });
    expect(
      mockContext.FinanceDelivery?.AMERICAS?.Spend?.setValue
    ).toHaveBeenCalledWith(2000);
    expect(
      mockErrorContext.FinanceDelivery.AMERICAS.Spend.setValue
    ).toHaveBeenCalledWith(true);
  });

  test("renders Countries dropdown", () => {
    const countriesDropdown = screen.getAllByLabelText(/Select Countries/i);
    expect(countriesDropdown[0]).toBeInTheDocument();
  });

  // test("handles country selection", () => {
  //   const countriesDropdown = screen.getAllByLabelText(/Select Countries/i);
  //   fireEvent.change(countriesDropdown[0], { value: ["USA"] });

  //   expect(
  //     mockContext.FinanceDelivery?.AMERICAS?.Country_Sites.setValue
  //   ).toHaveBeenCalled();
  //   expect(
  //     mockErrorContext.FinanceDelivery.AMERICAS.Country.setValue
  //   ).toHaveBeenCalledWith(true);
  // });

  // test("renders site inputs for selected countries", () => {
  //   // Mocking selected countries
  //   mockContext.FinanceDelivery?.AMERICAS?.Country_Sites.value.set("USA", 0);

  //   render(
  //     <MyContext.Provider value={mockContext}>
  //       <ErrorContext.Provider value={mockErrorContext}>
  //         <CountrySites />
  //       </ErrorContext.Provider>
  //     </MyContext.Provider>
  //   );

  //   expect(
  //     screen.getAllByLabelText(/Number of Sites for USA/i)
  //   ).toBeInTheDocument();
  // });

  //   test("updates site count correctly", () => {
  //     mockRegion.Country_Sites.value.set("USA", 0);

  //     render(
  //       <MyContext.Provider value={mockContextValue}>
  //         <ErrorContext.Provider value={mockErrorContext}>
  //           <CountrySites />
  //         </ErrorContext.Provider>
  //       </MyContext.Provider>
  //     );

  //     const siteInput = screen.getByLabelText(/Number of Sites for USA/i);
  //     fireEvent.change(siteInput, { target: { value: "5" } });

  //     expect(mockRegion.Country_Sites.setValue).toHaveBeenCalled();
  //     expect(mockErrorContext.Sites.setValue).toHaveBeenCalledWith(true);
  //   });

  test("handles regex input correctly", () => {
    const spendInput = screen.getAllByLabelText(/Total Managed Spend in USD/i);

    fireEvent.change(spendInput[0], { target: { value: "abc" } });

    expect(
      mockContext.FinanceDelivery?.AMERICAS?.Spend.setValue
    ).toBeCalledWith(0);
  });
});
