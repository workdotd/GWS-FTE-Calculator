import { render, screen } from "@testing-library/react";
import { Brand } from "../src/views/Brand/Brand";

test("renders Brand View", () => {
  render(<Brand />);
  const linkElement = screen.getByText(/CBRE/i);
  expect(linkElement).toBeInTheDocument();
});
