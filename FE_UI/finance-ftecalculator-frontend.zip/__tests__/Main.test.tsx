// Main.test.tsx

import React from "react";
import { render, screen } from "@testing-library/react";
import { MyContext } from "../src/context/FMContext";
import { ErrorContext } from "../src/context/ErrorContext";
import Main from "../src/components/Main/Main";
import { mockContext, mockErrorContext } from "../__mocks__/mockContext";

import { getSaveFD, setOptions } from "../src/utils/GetValues";
import { FDAPIRegionBased } from "../src/utils/FDSave";

describe("Main component", () => {
  it("should render Finance Management by default", () => {
    render(
      <ErrorContext.Provider value={mockErrorContext}>
        <MyContext.Provider value={mockContext}>
          <Main value={false} setViewSummary={() => {}} />
        </MyContext.Provider>
      </ErrorContext.Provider>
    );
    expect(screen.getByText("Finance Management")).toBeInTheDocument();
  });

  it("should render Finance Delivery on button click", () => {
    render(
      <ErrorContext.Provider value={mockErrorContext}>
        <MyContext.Provider value={mockContext}>
          <Main value={false} setViewSummary={() => {}} />
        </MyContext.Provider>
      </ErrorContext.Provider>
    );

    const fmButton = screen.getByText("Finance Management");
    const fdButton = screen.getByText("Finance Delivery");
    expect(fmButton).toBeInTheDocument();
    expect(fdButton).toBeInTheDocument();

    fdButton.click();
    expect(screen.queryByText("Finance Management")).toBeInTheDocument();
    expect(screen.getByText("Finance Delivery")).toBeInTheDocument();
  });

  // it("should call handleSave on button click for Finance Management", async () => {
  //   render(
  //     <ErrorContext.Provider value={mockErrorContext}>
  //       <MyContext.Provider value={mockContext}>
  //         <Main value={false} setViewSummary={() => {}} />
  //       </MyContext.Provider>
  //     </ErrorContext.Provider>
  //   );
  //   const saveButton = screen.getByText("Save & Calculate");
  //   saveButton.click();
  //   expect(mockContext.SaveFM.setValue).toHaveBeenCalled();
  // });

  //   it("should call handleSave on button click for Finance Delivery", () => {
  //     render(
  //       <ErrorContext.Provider value={mockErrorContext}>
  //         <MyContext.Provider value={mockContext}>
  //           <Main value={false} setViewSummary={() => {}} />
  //         </MyContext.Provider>
  //       </ErrorContext.Provider>
  //     );
  //     const fdButton = screen.getByText("Finance Delivery");
  //     fdButton.click();
  //     const saveButton = screen.getByText("Save & Calculate");
  //     saveButton.click();
  //     expect(jest.mocked(FDAPIRegionBased)).toHaveBeenCalled();
  //   });

  //   it("should show Activity Summary button when Save is enabled for FD", () => {
  //     jest.mocked(getSaveFD).mockReturnValueOnce(true);
  //     render(
  //       <ErrorContext.Provider value={mockErrorContext}>
  //         <MyContext.Provider value={mockContext}>
  //           <Main value={false} setViewSummary={() => {}} />
  //         </MyContext.Provider>
  //       </ErrorContext.Provider>
  //     );
  //     const fdButton = screen.getByText("Finance Delivery");
  //     fdButton.click();
  //     expect(screen.getByText("Activity Summary")).toBeInTheDocument();
  //   });

  // Add more tests for other functionalities like scrollToTop, handleChangeFreq, etc.
});
