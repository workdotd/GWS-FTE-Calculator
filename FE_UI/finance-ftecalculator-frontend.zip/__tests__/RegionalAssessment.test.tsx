import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { mockContext, mockErrorContext } from "../__mocks__/mockContext";
import { ErrorContext } from "../src/context/ErrorContext";
import { MyContext } from "../src/context/FMContext";

import RegionalAssessment from "../src/components/FinanceMgmt/RegionalAssessment";

describe("RegionalAssessment", () => {
  it("renders without crashing", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <RegionalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );
    expect(
      screen.getByText("Recommended Regional Finance Management Roles")
    ).toBeInTheDocument();
  });

  it("renders all three regions", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <RegionalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );
    expect(screen.getByLabelText("AMERICAS Role")).toBeInTheDocument();
    expect(screen.getByLabelText("EMEA Role")).toBeInTheDocument();
    expect(screen.getByLabelText("APAC Role")).toBeInTheDocument();
  });

  it("displays recommended roles for each region", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <RegionalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );
    expect(screen.getByText("AMERICAS Role")).toBeInTheDocument();
    expect(screen.getByText("EMEA Role")).toBeInTheDocument();
    expect(screen.getByText("APAC Role")).toBeInTheDocument();
  });
});
