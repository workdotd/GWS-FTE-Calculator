import React from "react";
import { render, screen } from "@testing-library/react";
import { mockContext } from "../__mocks__/mockContext";
import FMTable from "../src/components/Summary/FMTable";
import { MyContext } from "../src/context/FMContext";

describe("FMTable Component", () => {
  it("renders table with correct data when context is provided", () => {
    const { container } = render(
      <MyContext.Provider value={mockContext}>
        <FMTable />
      </MyContext.Provider>
    );

    // Check if the headers are rendered
    expect(screen.getByText("Regional Code")).toBeInTheDocument();
    expect(screen.getByText("Location")).toBeInTheDocument();
    expect(screen.getByText("FTE")).toBeInTheDocument();

    // Check if rows are rendered with correct values
    expect(screen.getByText("Global Roles")).toBeInTheDocument();
    expect(screen.getByText("Global Finance Director")).toBeInTheDocument();
    expect(screen.getByText("Global Location")).toBeInTheDocument();
    expect(screen.getByText("23")).toBeInTheDocument();

    expect(screen.getByText("AMERICAS")).toBeInTheDocument();
    expect(screen.getByText("Finance Manager")).toBeInTheDocument();
    expect(screen.getByText("New York")).toBeInTheDocument();
    expect(screen.getByText("10")).toBeInTheDocument();

    expect(screen.getByText("EMEA")).toBeInTheDocument();
    expect(screen.getByText("Finance Analyst")).toBeInTheDocument();
    expect(screen.getByText("London")).toBeInTheDocument();
    expect(screen.getByText("5")).toBeInTheDocument();

    expect(screen.getByText("APAC")).toBeInTheDocument();
    expect(screen.getByText("Finance Director")).toBeInTheDocument();
    expect(screen.getByText("Tokyo")).toBeInTheDocument();
    expect(screen.getByText("8")).toBeInTheDocument();

    // Check total row
    expect(screen.getByText("Total Finance Management")).toBeInTheDocument();
    expect(screen.getByText("46")).toBeInTheDocument();
  });

  it("throws an error when context is not provided", () => {
    // We expect an error to be thrown when context is not provided
    expect(() => render(<FMTable />)).toThrow(
      "Component must be used within a MyProvider"
    );
  });
});
