// CellData.test.tsx
import React from "react";
import { render, screen } from "@testing-library/react";
import { MyContext } from "../src/context/FMContext";
import CellData from "../src/components/Summary/Cell";
import { mockContext } from "../__mocks__/mockContext";

// Mocking the EmeraldTooltip component
jest.mock("@emerald-react/tooltip", () => ({
  EmeraldTooltip: ({ triggerElement, children }: any) => (
    <div data-testid="tooltip">
      <div>{children}</div>
    </div>
  ),
}));

describe("CellData Component", () => {
  const mockValue = "Test Value";

  it("renders with value when context is provided", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <CellData value={mockValue} />
      </MyContext.Provider>
    );

    const text = screen.getByText(mockValue);
    // Check if the tooltip is rendered with the correct value
    expect(text).toBeInTheDocument();
  });

  it("throws an error when context is not provided", () => {
    // We expect an error to be thrown when context is not provided
    expect(() => render(<CellData value={mockValue} />)).toThrow(
      "FinanceManagement must be used within a MyProvider"
    );
  });
});
