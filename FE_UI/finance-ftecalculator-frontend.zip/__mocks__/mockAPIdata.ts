import { FDActivitySummary } from "../src/utils/FDSave";

export const mockActivitySummaryData: FDActivitySummary[] = [
  { Activities: "Activity 1", Hours: 10 },
  { Activities: "Activity 2", Hours: 20 },
];
