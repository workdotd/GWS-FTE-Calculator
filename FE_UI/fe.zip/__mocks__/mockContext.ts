import { ErrorContextType } from "../src/context/ErrorContext";
// MockData.ts

import { MyContextType } from "../src/context/FMContext"; // Adjust the import path as necessary

import { ContextType } from "../src/context/ContextType"; // Adjust the import path as necessary
import { SetStateAction } from "react";

// Sample ContextType implementation
const createContextValue = <T>(value: T): ContextType<T> => ({
  value: value,
  setValue: jest.fn(), // Mocking the setValue function for testing purposes
});

// Mock data for unit testing
export const mockContext: MyContextType = {
  ClientName: createContextValue<string>("Test Client"),

  FinanceManagement: {
    RegionalAssessment: {
      AMERICAS: {
        Role: createContextValue<string>("None"),
        Growth: createContextValue<string>("10%"),
        Contract: createContextValue<string>("Contract A"),
        Performance: createContextValue<string>("Good"),
        Location: createContextValue<string>("New York"),
      },
      EMEA: {
        Role: createContextValue<string>("Finance Analyst"),
        Growth: createContextValue<string>("5%"),
        Contract: createContextValue<string>("Contract B"),
        Performance: createContextValue<string>("Average"),
        Location: createContextValue<string>("London"),
      },
      APAC: {
        Role: createContextValue<string>("Finance Director"),
        Growth: createContextValue<string>("15%"),
        Contract: createContextValue<string>("Contract C"),
        Performance: createContextValue<string>("Excellent"),
        Location: createContextValue<string>("Tokyo"),
      },
    },
    GlobalAssessment: {
      Region: createContextValue<Array<string>>(["AMERICAS", "EMEA", "APAC"]),
      RoleRequirement: createContextValue<string>("Various Roles Required"),
      Location: createContextValue<string>("Global Location"),
      Role: createContextValue<string>("Global Finance Director"),
      Spend: createContextValue<string>("$1,000,000"),
    },
  },

  FinanceDelivery: {
    FDRegion: createContextValue<string>("AMERICAS"),

    AMERICAS: {
      Spend: createContextValue<number>(500000),
      Country_Sites: createContextValue<Map<string, number>>(
        new Map([
          ["USA", 10],
          ["Canada", 5],
        ])
      ),
      ContractVariables: {
        Structure: createContextValue<string>("Flat Structure"),
        SpendRatio: createContextValue<string>("70/30"),
        Principal: createContextValue<string>("Principal A"),
        CRL: createContextValue<string>("CRL Value A"),
        TechStack: createContextValue<string>("Tech Stack A"),
        AutomationAdj: createContextValue<string>("Adjustment A"),
        BankAccount: createContextValue<string>("Bank Account A"),
      },
      ARAP: {
        Billing: createContextValue<string>("Monthly Billing"),
        FundRecon: createContextValue<string>("Fund Reconciliation A"),
        Payment: createContextValue<string>("Payment Method A"),
      },
      CBREReport: {
        OpenPOReview: createContextValue<string>("Review A"),
        BalanceSheetRecon: createContextValue<string>("Recon A"),
        MER: createContextValue<string>("MER A"),
        PTR: createContextValue<string>("PTR A"),
        PES: createContextValue<string>("PES A"),
        ASR: createContextValue<string>("ASR A"),
        MERAQ: createContextValue<string>("MERAQ A"),
        PRA: createContextValue<string>("PRA A"),
        OMBR: createContextValue<string>("OMBR A"),
        MEA: createContextValue<string>("MEA A"),
      },
      ClientReport: {
        MEA: createContextValue<string>("MEA Report A"),
        MOC: createContextValue<string>("MOC Report A"),
        CB: createContextValue<string>("CB Report A"),
        CF: createContextValue<string>("CF Report A"),
        CSR: createContextValue<string>("CSR Report A"),
        CFAS: createContextValue<string>("CFAS Report A"),
        CBAR: createContextValue<string>("CBAR Report A"),
        ReportType: createContextValue<string>("Monthly Report Type A"),
        Report_Freq: createContextValue<string>("Monthly Frequency A"),
      },
      DeliveryModel: createContextValue<string>("Delivery Model A"),
    },
    EMEA: {
      Spend: createContextValue<number>(300000),
      Country_Sites: createContextValue<Map<string, number>>(
        new Map([
          ["UK", 8],
          ["Germany", 4],
        ])
      ),
      ContractVariables: {
        Structure: createContextValue<string>("Flat Structure"),
        SpendRatio: createContextValue<string>("70/30"),
        Principal: createContextValue<string>("Principal A"),
        CRL: createContextValue<string>("CRL Value A"),
        TechStack: createContextValue<string>("Tech Stack A"),
        AutomationAdj: createContextValue<string>("Adjustment A"),
        BankAccount: createContextValue<string>("Bank Account A"),
      },
      ARAP: {
        Billing: createContextValue<string>("Monthly Billing"),
        FundRecon: createContextValue<string>("Fund Reconciliation A"),
        Payment: createContextValue<string>("Payment Method A"),
      },
      CBREReport: {
        OpenPOReview: createContextValue<string>("Review A"),
        BalanceSheetRecon: createContextValue<string>("Recon A"),
        MER: createContextValue<string>("MER A"),
        PTR: createContextValue<string>("PTR A"),
        PES: createContextValue<string>("PES A"),
        ASR: createContextValue<string>("ASR A"),
        MERAQ: createContextValue<string>("MERAQ A"),
        PRA: createContextValue<string>("PRA A"),
        OMBR: createContextValue<string>("OMBR A"),
        MEA: createContextValue<string>("MEA A"),
      },
      ClientReport: {
        MEA: createContextValue<string>("MEA Report A"),
        MOC: createContextValue<string>("MOC Report A"),
        CB: createContextValue<string>("CB Report A"),
        CF: createContextValue<string>("CF Report A"),
        CSR: createContextValue<string>("CSR Report A"),
        CFAS: createContextValue<string>("CFAS Report A"),
        CBAR: createContextValue<string>("CBAR Report A"),
        ReportType: createContextValue<string>("Monthly Report Type A"),
        Report_Freq: createContextValue<string>("Monthly Frequency A"),
      },
      DeliveryModel: createContextValue<string>("Delivery Model A"),
      // Additional properties can be filled similarly...
    },
    APAC: {
      Spend: createContextValue<number>(200000),
      Country_Sites: createContextValue<Map<string, number>>(
        new Map([
          ["Japan", 6],
          ["Australia", 3],
        ])
      ),
      ContractVariables: {
        Structure: createContextValue<string>("Flat Structure"),
        SpendRatio: createContextValue<string>("70/30"),
        Principal: createContextValue<string>("Principal A"),
        CRL: createContextValue<string>("CRL Value A"),
        TechStack: createContextValue<string>("Tech Stack A"),
        AutomationAdj: createContextValue<string>("Adjustment A"),
        BankAccount: createContextValue<string>("Bank Account A"),
      },
      ARAP: {
        Billing: createContextValue<string>("Monthly Billing"),
        FundRecon: createContextValue<string>("Fund Reconciliation A"),
        Payment: createContextValue<string>("Payment Method A"),
      },
      CBREReport: {
        OpenPOReview: createContextValue<string>("Review A"),
        BalanceSheetRecon: createContextValue<string>("Recon A"),
        MER: createContextValue<string>("MER A"),
        PTR: createContextValue<string>("PTR A"),
        PES: createContextValue<string>("PES A"),
        ASR: createContextValue<string>("ASR A"),
        MERAQ: createContextValue<string>("MERAQ A"),
        PRA: createContextValue<string>("PRA A"),
        OMBR: createContextValue<string>("OMBR A"),
        MEA: createContextValue<string>("MEA A"),
      },
      ClientReport: {
        MEA: createContextValue<string>("MEA Report A"),
        MOC: createContextValue<string>("MOC Report A"),
        CB: createContextValue<string>("CB Report A"),
        CF: createContextValue<string>("CF Report A"),
        CSR: createContextValue<string>("CSR Report A"),
        CFAS: createContextValue<string>("CFAS Report A"),
        CBAR: createContextValue<string>("CBAR Report A"),
        ReportType: createContextValue<string>("Monthly Report Type A"),
        Report_Freq: createContextValue<string>("Monthly Frequency A"),
      },
      DeliveryModel: createContextValue<string>("Delivery Model A"),
    },
  },

  SaveFM: createContextValue<boolean>(true),
  SaveFD: {
    AMS: createContextValue<boolean>(true),
    EMEA: createContextValue<boolean>(false),
    APAC: createContextValue<boolean>(true),
  },

  FMResponse: {
    AMERICAS: {
      Role: createContextValue("Finance Manager"),
      Location: createContextValue("New York"),
      FTE: createContextValue(10),
    },
    EMEA: {
      Role: createContextValue("Finance Analyst"),
      Location: createContextValue("London"),
      FTE: createContextValue(5),
    },
    APAC: {
      Role: createContextValue("Finance Director"),
      Location: createContextValue("Tokyo"),
      FTE: createContextValue(8),
    },
    Global: {
      Role: createContextValue("Global Finance Director"),
      Location: createContextValue("Global Location"),
      FTE: createContextValue(23),
    },
    TotalFM: createContextValue(46),
  },

  FDResponse: {
    AMERICAS: {
      RB: {
        FA: createContextValue(100),
        SFA: createContextValue(50),
        FM: createContextValue(20),
        TotalHours: createContextValue(170),
        TotalFTE: createContextValue(2),
      },
      ML: {
        FA: createContextValue(80),
        SFA: createContextValue(40),
        FM: createContextValue(15),
        TotalHours: createContextValue(135),
        TotalFTE: createContextValue(1.5),
      },
    },
    EMEA: {
      RB: {
        FA: createContextValue(90),
        SFA: createContextValue(45),
        FM: createContextValue(25),
        TotalHours: createContextValue(160),
        TotalFTE: createContextValue(2.2),
      },
      ML: {
        FA: createContextValue(70),
        SFA: createContextValue(35),
        FM: createContextValue(18),
        TotalHours: createContextValue(123),
        TotalFTE: createContextValue(1.8),
      },
    },
    APAC: {
      RB: {
        FA: createContextValue(110),
        SFA: createContextValue(55),
        FM: createContextValue(30),
        TotalHours: createContextValue(195),
        TotalFTE: createContextValue(2.5),
      },
      ML: {
        FA: createContextValue(90),
        SFA: createContextValue(45),
        FM: createContextValue(20),
        TotalHours: createContextValue(155),
        TotalFTE: createContextValue(1.9),
      },
    },
  },
  isFMLoading: createContextValue(false),
  isFDLoading: createContextValue(false),
};

export const mockErrorContext: ErrorContextType = {
  clientName: createContextValue(true),

  FinanceManagement: {
    AMERICAS: {
      Growth: createContextValue(true),
      Contract: createContextValue(true),
      Performance: createContextValue(true),
    },
    EMEA: {
      Growth: createContextValue(true),
      Contract: createContextValue(true),
      Performance: createContextValue(true),
    },
    APAC: {
      Growth: createContextValue(true),
      Contract: createContextValue(true),
      Performance: createContextValue(true),
    },
    Global: {
      Region: createContextValue(true),
      Requirement: createContextValue(true),
      Spend: createContextValue(true),
    },
  },

  FinanceDelivery: {
    AMERICAS: {
      Spend: createContextValue(true),
      Country: createContextValue(true),
      Sites: createContextValue(true),
    },
    EMEA: {
      Spend: createContextValue(true),
      Country: createContextValue(true),
      Sites: createContextValue(true),
    },
    APAC: {
      Spend: createContextValue(true),
      Country: createContextValue(true),
      Sites: createContextValue(true),
    },
  },
};
