import React from "react";

const ATable: React.FC = () => {
  return (
    <>
      <table className="table">
        <thead className="thead">
          <tr className="tr">
            <th>Finance Activity</th>
            <th>AMS</th>
          </tr>
        </thead>
        <tbody className="tbody">
          <tr className="tr">
            <td>Billing</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Fund Reconciliations</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Payment</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Monthly JDE period close and Open PO review</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Monthly JDE Balance Sheet Reconciliation</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Month End Revenue/Costs Adjustments</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Pass Through Reconciliation</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Payment Entries Submission</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Internal & External Audit Sampling Requests (SOC1 & SOX)</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate P&L Month End Review, Analysis & Queries</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Yearly Budget - Preparation, Review & Approval</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Monthly Forecast - Preparation, Review & Approval</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Corporate Operation Merit & Bonus Review</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>
              Client Month End Accruals - Open PO, Rental, Utilities etc.-
              Manual Journal Entries Posting
            </td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>
              Monthly Operational Call for Client Month End Close (Queries from
              FM - Finance Related)
            </td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>
              Client Budget - Management Fee & Payroll Calculation; Vendor Spend
              Data
            </td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Client Forecast - Vendor Spend</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Client Savings Report</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Client Finance Audit Support</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Client Billing to Actuals Reconciliation</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>Standard Report Frequency</td>{" "}
            {/* For the dropdown labeled as Standard Report */}
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>
              <b>Total - Standard Activities</b>
            </td>
            <td>
              <b>--</b>
            </td>
          </tr>
          <tr className="tr">
            <td>
              <b>Total - Manual Added Activities</b>
            </td>
            <td>
              <b>--</b>
            </td>
          </tr>
          <tr className="tr">
            <td>Ad-Hoc Overlay</td>
            <td>--</td>
          </tr>
          <tr className="tr">
            <td>
              <b>Total Est. Hours per Month</b>
            </td>
            <td>
              <b>--</b>
            </td>
          </tr>
          <tr className="tr">
            <td>
              <b>Shared Services Delivery</b>
            </td>
            <td>
              <b>--</b>
            </td>
          </tr>
          <tr className="tr">
            <td>
              <b>On-Site Delivery</b>
            </td>
            <td>
              <b>--</b>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
};

export default ATable;
