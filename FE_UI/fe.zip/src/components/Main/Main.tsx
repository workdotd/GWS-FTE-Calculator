import React, { useContext, useRef, useState } from "react";
import { EmeraldButton } from "@emerald-react/button";

import {
  EmeraldButtonVariant,
  EmeraldButtonShape,
  EmeraldButtonSize,
  EmeraldButtonAlignment,
} from "@emerald/nxcore";

import FinanceManagement from "../FinanceMgmt/FinanceManagement";
import "../../styles/Main.scss";
import FinanceDelivery from "../FinanceDelivery/FinanceDelivery";
import ActivitySummary from "../ActivitySummary/ActivitySummary";

import { MyContext } from "../../context/FMContext";
import {
  FMAPIFormat,
  setFMAPIData,
  setFMResponseData,
} from "../../utils/FMSave";
import { ErrorContext } from "../../context/ErrorContext";
import {
  FDAPIFormat,
  FDAPIRegionBased,
  setFDResponse,
} from "../../utils/FDSave";

import axiosInstance from "../../utils/interceptor";
import {
  changeSave,
  getRegion,
  getRegionFDError,
  getSaveFD,
} from "../../utils/GetValues";
import {
  ErrorHandlerFD,
  ErrorHandlerFM,
  ResetErrorContext,
} from "../../utils/ErrorHandler";

interface SetViewSummaryProps {
  value: boolean;
  setViewSummary: React.Dispatch<React.SetStateAction<boolean>>;
}

const Main: React.FC<SetViewSummaryProps> = (props) => {
  const [fm, setFm] = useState(true);
  const [fd, setFd] = useState(false);
  const [activitySummary, setActivitySummary] = useState(false);

  const context = useContext(MyContext);
  const errorContext = useContext(ErrorContext);

  const regionFDerror = getRegionFDError(context, errorContext);

  if (!context) {
    throw new Error("Context not found");
  }

  const switchFMFD = (value: string) => {
    if (value === "fm") {
      setFm(true);
      setFd(false);
    } else if (value === "fd") {
      setFm(false);
      setFd(true);
    }
  };

  const scrollableRefFM = useRef<HTMLDivElement>(null);
  const scrollableRefFD = useRef<HTMLDivElement>(null);

  function scrollToTop() {
    if (scrollableRefFM.current) {
      scrollableRefFM.current.scrollTop = 0;
    }
    if (scrollableRefFD.current) {
      scrollableRefFD.current.scrollTop = 0;
    }
  }

  const handleSave = (e: React.MouseEvent<Element, MouseEvent>) => {
    e.preventDefault();
    if (fm) {
      var dataFM: FMAPIFormat[] = [];

      // Resetting Error Context
      // ResetErrorContext(errorContext);

      if (errorContext?.FinanceManagement.AllNone.value) {
        errorContext?.FinanceManagement.AllNone.setValue(false);
      }

      // For Validations Errors
      try {
        dataFM = setFMAPIData(context);
        fetchFMData(dataFM);
      } catch (error) {
        console.log(error);
        ErrorHandlerFM(errorContext, error);
      }
    } else {
      var dataFD: FDAPIFormat[] = [];

      // For Validation Errors
      try {
        dataFD = FDAPIRegionBased(context);
        fetchFDData(dataFD);
      } catch (error) {
        console.log(error);
        ErrorHandlerFD(errorContext, regionFDerror, error);
      }
    }
  };

  const fetchFMData = async (postData: FMAPIFormat[]) => {
    try {
      context.isFMLoading.setValue(true);

      const response = await axiosInstance.post("finance_management", postData);
      setFMResponseData(context, response.data);

      context.isFMLoading.setValue(false);
      context.SaveFM.setValue(true);
    } catch (error) {
      console.log(error);
    } finally {
      console.log("API hitted");
    }
  };

  const fetchFDData = async (postData: FDAPIFormat[]) => {
    try {
      context.isFDLoading.setValue(true);

      const response = await axiosInstance.post("calculate_fte", postData);
      setFDResponse(context, response.data);

      // console.log(response.data);
      context.isFDLoading.setValue(false);
      changeSave(context, true);
    } catch (error) {
      console.log(error);
    } finally {
      console.log("API hitted");
    }
  };

  // Possible Optimisation, We can move all the handle function in one file and then resuse it from there
  const handleChangeFreq = () => {
    changeSave(context, false);

    var region = getRegion(context);

    region?.ARAP.Billing.setValue("Monthly");
    region?.ARAP.FundRecon.setValue("Monthly");
    region?.ARAP.Payment.setValue("Monthly");

    region?.CBREReport.ASR.setValue("Monthly");
    region?.CBREReport.BalanceSheetRecon.setValue("Monthly");
    region?.CBREReport.MEA.setValue("Monthly");
    region?.CBREReport.MER.setValue("Monthly");
    region?.CBREReport.MERAQ.setValue("Monthly");
    region?.CBREReport.OMBR.setValue("Monthly");
    region?.CBREReport.OpenPOReview.setValue("Monthly");
    region?.CBREReport.PES.setValue("Monthly");
    region?.CBREReport.PRA.setValue("Monthly");
    region?.CBREReport.PTR.setValue("Monthly");

    region?.ClientReport.CB.setValue("Monthly");
    region?.ClientReport.CBAR.setValue("Monthly");
    region?.ClientReport.CF.setValue("Monthly");
    region?.ClientReport.CFAS.setValue("Monthly");
    region?.ClientReport.CSR.setValue("Monthly");
    region?.ClientReport.MEA.setValue("Monthly");
    region?.ClientReport.MOC.setValue("Monthly");
    region?.ClientReport.Report_Freq.setValue("Monthly");
  };

  return (
    <>
      <div className="left-container">
        <div className="viewSummarySection-btn">
          <EmeraldButton
            label="Summary"
            icon={props.value ? "chevron_right" : "chevron_left"}
            type={EmeraldButtonVariant.Secondary}
            shape={EmeraldButtonShape.Rectangular}
            size={EmeraldButtonSize.Medium}
            iconPosition={EmeraldButtonAlignment.Right}
            onClick={() => {
              props.setViewSummary(!props.value);
            }}
          />
        </div>
        {activitySummary ? (
          <ActivitySummary setActivitySummary={setActivitySummary} />
        ) : (
          <>
            <div className="fm-fd-btn-container">
              <EmeraldButton
                label="Finance Management"
                type={
                  fm
                    ? EmeraldButtonVariant.Primary
                    : EmeraldButtonVariant.Secondary
                }
                onClick={() => switchFMFD("fm")}
              />
              <EmeraldButton
                label="Finance Delivery"
                type={
                  fd
                    ? EmeraldButtonVariant.Primary
                    : EmeraldButtonVariant.Secondary
                }
                onClick={() => switchFMFD("fd")}
              />
            </div>
            <div className="fm-fd-container">
              {fm && <FinanceManagement scrollableRef={scrollableRefFM} />}
              {fd && (
                <FinanceDelivery
                  scrollableRef={scrollableRefFD}
                  scrollToTop={() => scrollToTop()}
                />
              )}
            </div>
            <div className="top-save-btn-container">
              <EmeraldButton
                label="Top"
                className="custom-main-btn-style"
                type={EmeraldButtonVariant.Secondary}
                icon="north"
                onClick={() => {
                  scrollToTop();
                }}
              />
              {fd && (
                <EmeraldButton
                  label="Reset Frequency to Monthly"
                  className="custom-main-btn-style"
                  icon="replay"
                  type={EmeraldButtonVariant.Secondary}
                  onClick={() => handleChangeFreq()}
                />
              )}
              {fd && getSaveFD(context) && (
                <EmeraldButton
                  className="custom-main-btn-style"
                  label="Activity Summary"
                  icon="list_alt"
                  type={EmeraldButtonVariant.Light}
                  onClick={() => setActivitySummary(true)}
                />
              )}
              <EmeraldButton
                className="custom-main-btn-style"
                label="Save & Calculate"
                icon="calculate"
                onClick={(e: React.MouseEvent<Element, MouseEvent>) => {
                  handleSave(e);
                }}
              />
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default Main;
