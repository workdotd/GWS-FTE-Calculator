import React from "react";

import "../../styles/RegionsFD.scss";

import { EmeraldAccordionGroup } from "@emerald-react/accordion-group";

import ContractVariables from "./ContractVariables";

import { FDDropdowns } from './FDdropdowns';
import RegionFDSection from './RegionFDSection';
import CountrySites from "./CountrySites";

const RegionsFD: React.FC = () => {

  const inputs = FDDropdowns;

  return (
    <>
      <div className="fd-region-container">
        <EmeraldAccordionGroup
          data={[
            {
              children: <CountrySites />,
              title: "Country and Sites",
              openIcon: "keyboard_arrow_up",
              closeIcon: "keyboard_arrow_down",
              iconPosition: "right",
              className: "fd-accordian",
            },
            {
              children: <ContractVariables />,
              title: "Contract Variables",
              openIcon: "keyboard_arrow_up",
              closeIcon: "keyboard_arrow_down",
              iconPosition: "right",
              className: "fd-accordian",
            },
            ...inputs.map((element, i) => {
              return {
                children: <RegionFDSection element={element} />,
                title: element.section_title,
                openIcon: "keyboard_arrow_up",
                closeIcon: "keyboard_arrow_down",
                className: "fd-accordian",
              };
            }),
          ]}
        />
      </div>
    </>
  );
};

export default RegionsFD;
