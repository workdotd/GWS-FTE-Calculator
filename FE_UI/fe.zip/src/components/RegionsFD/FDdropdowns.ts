export interface Dropdowns {
    label: string,
}

export interface Sections {
    section_title: string,
    dropdowns: Dropdowns[],
}

export const FDDropdowns: Sections[] = [{
        section_title: "AR/AP Activities",
        dropdowns: [
            { label: 'Billing'},
            { label: 'Fund Reconciliations'},
            { label: 'Payment' },
        ]
    },{
        section_title: "CBRE Reporting Activities",
        dropdowns: [
            { label: "Monthly JDE period close and Open PO review" },
            { label: "Monthly JDE Balance Sheet Reconciliation" },
            { label: "Corporate Month End Revenue/Costs Adjustments" },
            { label: "Corporate Pass Through Reconciliation" },
            { label: "Corporate Payment Entries Submission" },
            { label: "Internal & External Audit Sampling Requests (SOC1 & SOX)" },
            { label: "Corporate P&L Month End Review, Analysis & Queries" },
            { label: "Corporate Yearly Budget - Preparation, Review & Approval" },
            { label: "Corporate Monthly Forecast - Preparation, Review & Approval" },
            { label: "Corporate Operation Merit & Bonus Review" },
        ]
    },{
        section_title: "Client Reporting Activities",
        dropdowns: [
            { label: "Client Month End Accruals - Open PO, Rental, Utilities etc.- Manual Journal Entries Posting" },
            { label: "Monthly Operational Call for Client Month End Close (Queries from FM - Finance Related)" },
            { label: "Client Budget - Management Fee & Payroll Calculation; Vendor Spend Data" },
            { label: "Client Forecast - Vendor Spend" },
            { label: "Client Savings Report" },
            { label: "Client Finance Audit Support" },
            { label: "Client Billing to Actuals Reconciliation" },
            { label: "Report Type"},
            { label: "Report Freq" }, // For the dropdown labeled as Standard Report
        ]
    },{
        section_title: "Delivery Model",
        dropdowns: [
            {label: "Select Delivery Model (required)"}
        ]
    }
    
]