import React from "react";
import ClientSetUp from "../ClientSetUp/ClientSetUp";
import "../../styles/Header.scss";

interface HeaderProps {
  setDrawer: React.Dispatch<React.SetStateAction<boolean>>;
}

const Header: React.FC<HeaderProps> = (props) => {
  return (
    <div className="main-header">
      <div className="left-section AppTitle-Container">
        <h5 className="AppTitle">Finance FTE Calculator</h5>
      </div>
      <div className="right-section">
        <ClientSetUp setDrawer={props.setDrawer} />
      </div>
    </div>
  );
};

export default Header;
