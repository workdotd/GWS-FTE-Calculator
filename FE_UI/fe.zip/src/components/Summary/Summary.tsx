import React, { useContext } from "react";
import "../../styles/Summary.scss";
import "../../styles/SummaryTable.scss";

import { EmeraldAccordionGroup } from "@emerald-react/accordion-group";
import { EmeraldIconButton } from "@emerald-react/icon-button";
import { EmeraldProgressSpinner } from "@emerald-react/progress-indicator";

import FMTable from "./FMTable";
import { setFMAPIData } from "../../utils/FMSave";
import { MyContext } from "../../context/FMContext";
import axiosInstance from "../../utils/interceptor";
import FDTable from "./FDTable";
import { FDAPIRegionBased } from "../../utils/FDSave";
import { getSaveFD } from "../../utils/GetValues";

const Summary: React.FC = () => {
  const context = useContext(MyContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  return (
    <>
      <div className="summary-container">
        <h6>Summary</h6>
        <EmeraldAccordionGroup
          data={[
            {
              children: context.isFMLoading.value ? (
                <div className="loading">
                  <EmeraldProgressSpinner determinate={false} />
                </div>
              ) : (
                <FMTable />
              ),
              titleTemplate: () => <FMTitle />,
              openIcon: "keyboard_arrow_up",
              closeIcon: "keyboard_arrow_down",
              iconPosition: "right",
            },
            {
              children: context.isFDLoading.value ? (
                <div className="loading">
                  <EmeraldProgressSpinner determinate={false} />
                </div>
              ) : (
                <FDTable />
              ),
              titleTemplate: () => <FDTitle />,
              openIcon: "keyboard_arrow_up",
              closeIcon: "keyboard_arrow_down",
              iconPosition: "right",
            },
          ]}
          openMultiple
        />
      </div>
    </>
  );
};

const FMTitle = () => {
  const context = useContext(MyContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  const handleDownload = async () => {
    var data = setFMAPIData(context);

    try {
      const response = await axiosInstance.post(
        "finance_management/fm_summary_download",
        data,
        {
          responseType: "blob",
        }
      );

      const pdfblob = new Blob([response.data], { type: "application/csv" });

      const url = window.URL.createObjectURL(pdfblob);

      const tempLink = document.createElement("a");
      tempLink.href = url;
      tempLink.setAttribute("download", `FM_Summary_${Date.now()}.csv`);

      document.body.appendChild(tempLink);
      tempLink.click();

      document.body.removeChild(tempLink);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.log(error);
    } finally {
      console.log("API Hitted");
    }
  };

  return (
    <div className="fm-summary-title">
      <div>Finance Management Summary</div>
      <EmeraldIconButton
        icon="download"
        type="Secondary"
        size="Small"
        onClick={(event) => {
          event.stopPropagation();
          event.preventDefault();
          handleDownload();
        }}
        disabled={context.SaveFM.value ? false : true}
      />
    </div>
  );
};

const FDTitle = () => {
  const context = useContext(MyContext);

  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  const handleDownload = async () => {
    var data = FDAPIRegionBased(context);

    try {
      const response = await axiosInstance.post(
        "calculate_fte/activity_summary/download",
        data,
        {
          responseType: "blob",
        }
      );

      const pdfblob = new Blob([response.data], { type: "application/xlsx" });

      const url = window.URL.createObjectURL(pdfblob);

      const tempLink = document.createElement("a");
      tempLink.href = url;
      tempLink.setAttribute("download", `FD_Summary_${Date.now()}.xlsx`);

      document.body.appendChild(tempLink);
      tempLink.click();

      document.body.removeChild(tempLink);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.log(error);
    } finally {
      console.log("API Hit");
    }
  };

  return (
    <div className="fd-summary-title">
      <div>Finance Delivery Summary</div>
      <EmeraldIconButton
        className="fd-summary-download-btn"
        icon="download"
        type="Secondary"
        size="Small"
        onClick={(event) => {
          event.stopPropagation();
          event.preventDefault();
          handleDownload();
        }}
        disabled={getSaveFD(context) ? false : true}
      />
    </div>
  );
};

export default Summary;
