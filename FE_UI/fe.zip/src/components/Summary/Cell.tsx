import { EmeraldTooltip } from "@emerald-react/tooltip";
import { useContext } from "react";
import { MyContext } from "../../context/FMContext";

interface CellProps {
  value: string | number | undefined;
  column?: number;
}

const CellData: React.FC<CellProps> = ({ value, column }) => {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error("FinanceManagement must be used within a MyProvider");
  }

  // if(column === 0 || context.Save.value) {
  return (
    <EmeraldTooltip triggerElement={<span>{value}</span>} placement="top">
      {value}
    </EmeraldTooltip>
  );
  //     } else {
  //         return <EmeraldTooltip triggerElement={<span>--</span>} placement='top'>
  //             --
  //         </EmeraldTooltip>
  //     }
};

export default CellData;
