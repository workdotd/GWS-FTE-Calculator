import { Options } from "./Options";

// Delivery Model
export const DeliveryModelValues: Options[] = [
  { label: "On-site", selected: true, value: "On-site" },
  { label: "Mixed", value: "Mixed" },
  { label: "Shared Services", value: "Shared Services" },
];

export function getDeliveryModelOptions(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return DeliveryModelValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return DeliveryModelValues;
  }
}

// Frequency Values

export const FrequencyValues: Options[] = [
  { label: "None", value: "None" },
  { label: "Weekly", value: "Weekly" },
  { label: "Bi-Weekly", value: "Bi-Weekly" },
  { label: "Monthly", value: "Monthly" },
  { label: "Quarterly", value: "Quarterly" },
  { label: "Yearly", value: "Yearly" },
];

export function getFrequencyOptions(
  selectedValue: string | undefined
): Options[] {
  if (selectedValue) {
    return FrequencyValues.map((option) => ({
      ...option,
      selected: option.value === selectedValue,
    }));
  } else {
    return FrequencyValues;
  }
}
