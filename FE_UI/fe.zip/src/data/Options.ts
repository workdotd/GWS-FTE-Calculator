export interface Options {
    label: string;
    selected?: boolean;
    value: any;
}