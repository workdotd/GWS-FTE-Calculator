import React, { useEffect, useState } from "react";
import GlobalHeader from "../../components/GlobalHeader/GlobalHeader";
import Header from "../../components/Header/Header";
import Main from "../../components/Main/Main";
import Summary from "../../components/Summary/Summary";
import Drawer from "../../components/Drawer/Drawer";

import { MyProvider } from "../../context/Provider";

import { EmeraldDrawer } from "@emerald-react/drawer";
import { EmeraldIconButton } from "@emerald-react/icon-button";

import "../../styles/HomePage.scss";
import { ErrorProvider } from "../../context/ErrorProvider";
import { useNavigate } from "react-router-dom";
import { useAuth } from "react-oidc-context";

const HomePage: React.FC = () => {
  const [drawer, setDrawer] = useState(false);
  const [viewSummary, setViewSummary] = useState(false);

  const navigate = useNavigate();
  const auth = useAuth();

  useEffect(() => {
    const storedAuthState = sessionStorage.getItem("isAuthenticated");

    if (storedAuthState === "true") {
      auth.isAuthenticated = true;
    }

    if (!auth.isAuthenticated || auth.user?.expired) {
      sessionStorage.clear();
      navigate("/");
    } else {
      sessionStorage.setItem("token", auth.user?.access_token || "");
      sessionStorage.setItem("isAuthenticated", "true");
    }
  }, [auth.isAuthenticated, auth.user?.expired, navigate]);

  return (
    <>
      <ErrorProvider>
        <MyProvider>
          <EmeraldDrawer
            content={<Drawer />}
            header={
              <EmeraldIconButton
                onClick={() => setDrawer(false)}
                className="drawerCloseIcon"
                enableRipple={false}
                icon="close"
              />
            }
            classes="custom-drawer-style"
            title="Disclaimer"
            type="modal"
            open={drawer}
            dir={"rtl"}
            // onOpen={(e) => console.log(e)}
            onClose={(e) => setDrawer(false)}
          >
            <GlobalHeader />
            <Header setDrawer={setDrawer} />
            <div className="body-container">
              <Main setViewSummary={setViewSummary} value={viewSummary} />
              {viewSummary ? <Summary /> : null}
            </div>
          </EmeraldDrawer>
        </MyProvider>
      </ErrorProvider>
    </>
  );
};

export default HomePage;
