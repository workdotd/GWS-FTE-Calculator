import styles from "../../styles/brand.module.scss";

export const Brand: React.FC = () => {
  return (
    <div className={styles.brand}>
      <div className={styles.brandText}>CBRE</div>
      <div className={styles.brandText}>FTE Calculator</div>
    </div>
  );
};
