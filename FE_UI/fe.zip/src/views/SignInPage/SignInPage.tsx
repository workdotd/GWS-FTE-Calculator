import { SignInDialog } from "../SignInDialog/SignInDialog";
import bgImage from "../../assets/images/bg-image.png";
import style from "../../styles/signInPage.module.scss";

export const SignInPage: React.FC = () => {
  return (
    <main className={style.signInFullScreen}>
      <section className={style.signInContainer}>
        <img
          src={bgImage}
          className={style.backgroundImage}
          alt="CBRE FTE Background"
        />
        <SignInDialog />
      </section>
    </main>
  );
};
