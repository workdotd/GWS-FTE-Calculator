/* eslint-disable react/prop-types */
// eslint-disable-next-line

import { BrowserRouter, Routes, Route } from "react-router-dom";

import "./App.scss";

import HomePage from "./views/HomePage/HomePage";
import { SignInPage } from "./views/SignInPage/SignInPage";
import { CallBack } from "./views/Callback/CallBack";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/callback" element={<CallBack />} />
        <Route path="/" element={<SignInPage />} />
        <Route path="/home" element={<HomePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
