export const oidcConfig = {
  authority: process.env.REACT_APP_AUTHORITY,
  client_id: process.env.REACT_APP_CLIENT_ID,
  redirect_uri: process.env.REACT_APP_CALLBACK,
  response_type: "code",
  // client_secret: "XxK8Q~ijTpvj1.0JKRIrep-V1zvE86Y6v2yq_bm8",
  scope: process.env.REACT_APP_SCOPE,
  post_logout_redirect_uri: process.env.REACT_APP_CALLBACK,
  code_challenge_method: "S256",
};
