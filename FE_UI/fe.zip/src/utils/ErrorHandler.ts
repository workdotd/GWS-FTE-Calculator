import {
  ErrorContextType,
  RegionFDErrorType,
  RegionFMErrorType,
} from "../context/ErrorContext";

export class RegionError extends Error {
  region: string;

  constructor(region: any, message: string | undefined) {
    super(message);
    this.name = "RegionError";
    this.region = region;
  }
}

// Financial Delivery
export const ErrorHandlerFD = (
  context: ErrorContextType | undefined,
  region: RegionFDErrorType | undefined,
  error: any | undefined
) => {
  if (error?.message === "Client Name is required.") {
    context?.clientName.setValue(false);
  } else {
    if (
      error.message === "Spend cannot be zero." ||
      error.message === "Spend cannot be more than 2,147,483,647."
    ) {
      region?.Spend.setValue(false);
    } else if (error?.message === "Country is required.") {
      region?.Country.setValue(false);
    } else if (error?.message === "Sites cannot be Zero.") {
      region?.Sites.setValue(false);
    }
  }
  // As more as per validations
};

// Financial Management
export const ErrorHandlerFMRegion = (
  region: RegionFMErrorType | undefined,
  error: any | undefined
) => {
  if (error?.message === "Contract Value cannot be None since Role is None") {
    region?.Contract.setValue(false);
  } else if (
    error?.message === "Growth Value cannot be None since Role is None"
  ) {
    region?.Growth.setValue(false);
  } else if (
    error?.message === "Performance Value cannot be None since Role is None"
  ) {
    region?.Performance.setValue(false);
  }
};

export const ErrorHandlerFM = (
  context: ErrorContextType | undefined,
  error: any | undefined
) => {
  if (error.message === "All regions are in-valid") {
    // Add a context bool state to deal with this error and implemnt it in the UI
    context?.FinanceManagement.AllNone.setValue(true);
  } else if (error?.region === "AMS") {
    ErrorHandlerFMRegion(context?.FinanceManagement.AMERICAS, error);
  } else if (error?.region === "EMEA") {
    ErrorHandlerFMRegion(context?.FinanceManagement.EMEA, error);
  } else if (error?.region === "APAC") {
    ErrorHandlerFMRegion(context?.FinanceManagement.APAC, error);
  } else {
    // For Global
    if (error?.message === "Global Region must be Provided") {
      context?.FinanceManagement.Global.Region.setValue(false);
    } else if (error?.message === "Global Role Requirement is required") {
      context?.FinanceManagement.Global.Requirement.setValue(false);
    } else if (error?.message === "Global Spend must be Provided") {
      context?.FinanceManagement.Global.Spend.setValue(false);
    }
  }
};

export const ResetErrorContext = (context: ErrorContextType | undefined) => {
  // Here true means is Invalid
  context?.FinanceManagement.AllNone.setValue(false);

  // here true means is Valid
  context?.clientName.setValue(true);

  context?.FinanceManagement.AMERICAS.Growth.setValue(true);
  context?.FinanceManagement.AMERICAS.Contract.setValue(true);
  context?.FinanceManagement.AMERICAS.Performance.setValue(true);

  context?.FinanceManagement.EMEA.Growth.setValue(true);
  context?.FinanceManagement.EMEA.Contract.setValue(true);
  context?.FinanceManagement.EMEA.Performance.setValue(true);

  context?.FinanceManagement.APAC.Growth.setValue(true);
  context?.FinanceManagement.APAC.Contract.setValue(true);
  context?.FinanceManagement.APAC.Performance.setValue(true);

  context?.FinanceManagement.Global.Region.setValue(true);
  context?.FinanceManagement.Global.Requirement.setValue(true);
  context?.FinanceManagement.Global.Spend.setValue(true);

  context?.FinanceDelivery.AMERICAS.Spend.setValue(true);
  context?.FinanceDelivery.AMERICAS.Country.setValue(true);
  context?.FinanceDelivery.AMERICAS.Sites.setValue(true);

  context?.FinanceDelivery.EMEA.Spend.setValue(true);
  context?.FinanceDelivery.EMEA.Country.setValue(true);
  context?.FinanceDelivery.EMEA.Sites.setValue(true);

  context?.FinanceDelivery.APAC.Spend.setValue(true);
  context?.FinanceDelivery.APAC.Country.setValue(true);
  context?.FinanceDelivery.APAC.Sites.setValue(true);
};
