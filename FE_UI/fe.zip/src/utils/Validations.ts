import {
  MyContextType,
  RegionFDType,
  RegionFMType,
} from "../context/FMContext";
import { RegionError } from "./ErrorHandler";

// Finance Delivery
export const validateFDInput = (
  context: RegionFDType | undefined,
  clientName: string | undefined
) => {
  if (!clientName) {
    throw new Error("Client Name is required.");
  } else if (!context?.Spend.value) {
    throw new Error("Spend cannot be zero.");
  } else if (context.Spend.value > 0 && context.Spend.value >= 2147483647) {
    throw new Error("Spend cannot be more than 2,147,483,647.");
  }
  if (!context?.Country_Sites.value.size) {
    throw new Error("Country is required.");
  } else {
    context.Country_Sites.value.forEach((value) => {
      if (!value) {
        throw new Error("Sites cannot be Zero.");
      }
    });
  }
  // Add more validations as needed
};

// Finance Management
export const validateFMInput = (context: MyContextType | undefined) => {
  const Regional = context?.FinanceManagement?.RegionalAssessment;
  const Global = context?.FinanceManagement?.GlobalAssessment;

  // Validate ---> All Regions must be valid
  // validateFMRegional(Regional?.AMERICAS, "AMS");
  // validateFMRegional(Regional?.EMEA, "EMEA");
  // validateFMRegional(Regional?.APAC, "APAC");

  // Validate ---> Any Region is valid or else throw error
  if (
    !validateFMRegionalBool(Regional?.AMERICAS, "AMS") &&
    !validateFMRegionalBool(Regional?.EMEA, "EMEA") &&
    !validateFMRegionalBool(Regional?.APAC, "APAC")
  ) {
    throw new Error("All regions are in-valid");
  }

  // Validate ---> Role is Selected or GCP Values are given
  // if (invalidGCPRole(Regional?.AMERICAS, "AMS")) {
  //   validateFMRegional(Regional?.AMERICAS, "AMS");
  // } else if (invalidGCPRole(Regional?.EMEA, "EMEA")) {
  //   validateFMRegional(Regional?.EMEA, "EMEA");
  // } else if (invalidGCPRole(Regional?.APAC, "APAC")) {
  //   validateFMRegional(Regional?.APAC, "APAC");
  // }

  // Global
  if (!Global?.Region?.value.length) {
    throw new Error("Global Region must be Provided");
  }

  if (!Global?.RoleRequirement?.value) {
    throw new Error("Global Role Requirement is required");
  } else {
    if (!Global?.Spend?.value) {
      throw new Error("Global Spend must be Provided");
    }
  }

  // if(Global?.Location?.value === 'None') {
  //     throw new Error("Global Location Value must be Provided");
  // }
};

export const validateFMRegional = (
  context: RegionFMType | undefined,
  region: string
) => {
  if (context?.Role?.value === "None") {
    if (context.Growth?.value === "None") {
      throw new RegionError(
        region,
        "Growth Value cannot be None since Role is None"
      );
    } else if (context.Contract?.value === "None") {
      throw new RegionError(
        region,
        "Contract Value cannot be None since Role is None"
      );
    } else if (context.Performance?.value === "None") {
      throw new RegionError(
        region,
        "Performance Value cannot be None since Role is None"
      );
    }
    // else if(context.Location?.value === 'None'){
    //     throw new Error("Regional Location Value must be given");
    // }
  }
};

export function validateFMRegionalBool(
  context: RegionFMType | undefined,
  region: string
) {
  if (context?.Role?.value !== "None") {
    return true;
  } else {
    if (
      context.Growth?.value !== "None" &&
      context.Contract?.value !== "None" &&
      context.Performance?.value !== "None"
    ) {
      return true;
    } else {
      return false;
    }
  }
}

export function invalidGCPRole(
  context: RegionFMType | undefined,
  region: string
) {
  if (context?.Role?.value !== "None") {
    return false;
  } else {
    if (
      context.Growth?.value === "None" &&
      context.Contract?.value === "None" &&
      context.Performance?.value === "None"
    ) {
      return false;
    } else if (
      context.Growth?.value !== "None" &&
      context.Contract?.value !== "None" &&
      context.Performance?.value !== "None"
    ) {
      return false;
    }
    return true;
  }
}
