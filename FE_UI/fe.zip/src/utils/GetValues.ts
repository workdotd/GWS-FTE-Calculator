import { ErrorContextType, RegionFDErrorType } from "../context/ErrorContext";
import {
  ContractVariablesType,
  FDResponseType,
  MyContextType,
  RegionFDType,
} from "../context/FMContext";

import {
  FMRolesAMS,
  GrowthValuesAMS,
  ContractValuesAMS,
  PerformanceValuesAMS,
  FMRolesEMEA,
  GrowthValuesEMEA,
  ContractValuesEMEA,
  PerformanceValuesEMEA,
  FMRolesAPAC,
  GrowthValuesAPAC,
  ContractValuesAPAC,
  PerformanceValuesAPAC,
} from "../data/FMRole_GCPValues";
import { Options } from "../data/Options";
import { AMSLocFD, APACLocFD, EMEALocFD } from "../data/RoleLocations";

export const getRegion = (
  context: MyContextType | undefined
): RegionFDType | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return context?.FinanceDelivery?.AMERICAS;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return context?.FinanceDelivery?.EMEA;
  } else {
    return context?.FinanceDelivery?.APAC;
  }
};

export const getLocations = (
  context: MyContextType | undefined
): Array<Options> => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return AMSLocFD;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return EMEALocFD;
  } else {
    return APACLocFD;
  }
};

export const setOptions = (name: string): Array<Array<Options>> => {
  if (name === "Americas") {
    return [
      FMRolesAMS,
      GrowthValuesAMS,
      ContractValuesAMS,
      PerformanceValuesAMS,
    ];
  } else if (name === "Emea") {
    return [
      FMRolesEMEA,
      GrowthValuesEMEA,
      ContractValuesEMEA,
      PerformanceValuesEMEA,
    ];
  } else if (name === "Apac") {
    return [
      FMRolesAPAC,
      GrowthValuesAPAC,
      ContractValuesAPAC,
      PerformanceValuesAPAC,
    ];
  } else {
    return [
      FMRolesAMS,
      GrowthValuesAMS,
      ContractValuesAMS,
      PerformanceValuesAMS,
    ];
  }
};

export const getRegionSummary = (
  context: MyContextType | undefined
): FDResponseType | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return context?.FDResponse.AMERICAS;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return context?.FDResponse?.EMEA;
  } else {
    return context?.FDResponse?.APAC;
  }
};

export const getSaveFD = (
  context: MyContextType | undefined
): boolean | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return context?.SaveFD.AMS.value;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return context?.SaveFD.EMEA.value;
  } else {
    return context?.SaveFD.APAC.value;
  }
};

export const changeSave = (
  context: MyContextType | undefined,
  value: boolean
) => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    context?.SaveFD.AMS.setValue(value);
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    context?.SaveFD.EMEA.setValue(value);
  } else {
    context?.SaveFD.APAC.setValue(value);
  }
};

// Contract Values
export const getContractVariables = (
  context: MyContextType | undefined
): ContractVariablesType | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return context?.FinanceDelivery?.AMERICAS?.ContractVariables;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return context?.FinanceDelivery?.EMEA?.ContractVariables;
  } else {
    return context?.FinanceDelivery?.APAC?.ContractVariables;
  }
};

// Error

export const getRegionFDError = (
  context: MyContextType | undefined,
  errorContext: ErrorContextType | undefined
): RegionFDErrorType | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return errorContext?.FinanceDelivery.AMERICAS;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return errorContext?.FinanceDelivery?.EMEA;
  } else {
    return errorContext?.FinanceDelivery?.APAC;
  }
};

export const getRegionFMError = (
  context: MyContextType | undefined,
  errorContext: ErrorContextType | undefined
): RegionFDErrorType | undefined => {
  if (context?.FinanceDelivery?.FDRegion?.value === "AMERICAS") {
    return errorContext?.FinanceDelivery.AMERICAS;
  } else if (context?.FinanceDelivery?.FDRegion?.value === "EMEA") {
    return errorContext?.FinanceDelivery?.EMEA;
  } else {
    return errorContext?.FinanceDelivery?.APAC;
  }
};
