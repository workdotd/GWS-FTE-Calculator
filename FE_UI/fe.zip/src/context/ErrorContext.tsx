import { createContext } from "react";
import { ContextType } from "./ContextType";

export type ErrorContextType = {
  clientName: ContextType<boolean>;

  FinanceManagement: {
    AMERICAS: RegionFMErrorType;
    EMEA: RegionFMErrorType;
    APAC: RegionFMErrorType;
    Global: {
      Region: ContextType<boolean>;
      Requirement: ContextType<boolean>;
      Spend: ContextType<boolean>;
    };
    AllNone: ContextType<boolean>;
  };

  FinanceDelivery: {
    AMERICAS: RegionFDErrorType;
    EMEA: RegionFDErrorType;
    APAC: RegionFDErrorType;
  };
};

export type RegionFMErrorType = {
  Growth: ContextType<boolean>;
  Contract: ContextType<boolean>;
  Performance: ContextType<boolean>;
};

export type RegionFDErrorType = {
  Spend: ContextType<boolean>;
  Country: ContextType<boolean>;
  Sites: ContextType<boolean>;
};

export const ErrorContext = createContext<ErrorContextType | undefined>(
  undefined
);
