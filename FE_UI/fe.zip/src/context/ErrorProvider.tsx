import React, { ReactNode, useState } from "react";
import { ErrorContext, ErrorContextType } from "./ErrorContext";

type ErrorProviderProps = {
  children: ReactNode;
};

export const ErrorProvider: React.FC<ErrorProviderProps> = ({ children }) => {
  const [clientName, setclientName] = useState<boolean>(true);

  // State Variables with Prefixes
  const [AMS_growth, setAMS_growth] = useState<boolean>(true);
  const [AMS_contract, setAMS_contract] = useState<boolean>(true);
  const [AMS_performance, setAMS_performance] = useState<boolean>(true);

  const [EMEA_growth, setEMEA_growth] = useState<boolean>(true);
  const [EMEA_contract, setEMEA_contract] = useState<boolean>(true);
  const [EMEA_performance, setEMEA_performance] = useState<boolean>(true);

  const [APAC_growth, setAPAC_growth] = useState<boolean>(true);
  const [APAC_contract, setAPAC_contract] = useState<boolean>(true);
  const [APAC_performance, setAPAC_performance] = useState<boolean>(true);

  // Global
  const [Region, setRegion] = useState<boolean>(true);
  const [Requirement, setRequirement] = useState<boolean>(true);
  const [GlobalSpend, setGlobalSpend] = useState<boolean>(true);

  // AllNone
  const [AllNone, setAllNone] = useState<boolean>(false);

  // FinanceManagement Object
  const FinanceManagement = {
    AMERICAS: {
      Growth: {
        value: AMS_growth,
        setValue: setAMS_growth,
      },
      Contract: {
        value: AMS_contract,
        setValue: setAMS_contract,
      },
      Performance: {
        value: AMS_performance,
        setValue: setAMS_performance,
      },
    },
    EMEA: {
      Growth: {
        value: EMEA_growth,
        setValue: setEMEA_growth,
      },
      Contract: {
        value: EMEA_contract,
        setValue: setEMEA_contract,
      },
      Performance: {
        value: EMEA_performance,
        setValue: setEMEA_performance,
      },
    },
    APAC: {
      Growth: {
        value: APAC_growth,
        setValue: setAPAC_growth,
      },
      Contract: {
        value: APAC_contract,
        setValue: setAPAC_contract,
      },
      Performance: {
        value: APAC_performance,
        setValue: setAPAC_performance,
      },
    },
    Global: {
      Region: {
        value: Region,
        setValue: setRegion,
      },
      Requirement: {
        value: Requirement,
        setValue: setRequirement,
      },
      Spend: {
        value: GlobalSpend,
        setValue: setGlobalSpend,
      },
    },
    AllNone: {
      value: AllNone,
      setValue: setAllNone,
    },
  };

  const [AMS_spend, setAMS_spend] = useState<boolean>(true);
  const [AMS_country, setAMS_country] = useState<boolean>(true);
  const [AMS_sites, setAMS_sites] = useState<boolean>(true);

  const [EMEA_spend, setEMEA_spend] = useState<boolean>(true);
  const [EMEA_country, setEMEA_country] = useState<boolean>(true);
  const [EMEA_sites, setEMEA_sites] = useState<boolean>(true);

  const [APAC_spend, setAPAC_spend] = useState<boolean>(true);
  const [APAC_country, setAPAC_country] = useState<boolean>(true);
  const [APAC_sites, setAPAC_sites] = useState<boolean>(true);

  // FinanceDelivery Object
  const FinanceDelivery = {
    AMERICAS: {
      Spend: {
        value: AMS_spend,
        setValue: setAMS_spend,
      },
      Country: {
        value: AMS_country,
        setValue: setAMS_country,
      },
      Sites: {
        value: AMS_sites,
        setValue: setAMS_sites,
      },
    },
    EMEA: {
      Spend: {
        value: EMEA_spend,
        setValue: setEMEA_spend,
      },
      Country: {
        value: EMEA_country,
        setValue: setEMEA_country,
      },
      Sites: {
        value: EMEA_sites,
        setValue: setEMEA_sites,
      },
    },
    APAC: {
      Spend: {
        value: APAC_spend,
        setValue: setAPAC_spend,
      },
      Country: {
        value: APAC_country,
        setValue: setAPAC_country,
      },
      Sites: {
        value: APAC_sites,
        setValue: setAPAC_sites,
      },
    },
  };

  const Errors: ErrorContextType = {
    clientName: {
      value: clientName,
      setValue: setclientName,
    },
    FinanceManagement: FinanceManagement,
    FinanceDelivery: FinanceDelivery,
  };

  return (
    <ErrorContext.Provider value={Errors}>{children}</ErrorContext.Provider>
  );
};
