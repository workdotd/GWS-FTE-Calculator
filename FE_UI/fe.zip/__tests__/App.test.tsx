import React from "react";
import { render, screen } from "@testing-library/react";
import App from "../src/App";
import bgImg from "../src/assets/images/bg-image.png";

jest.mock("../src/assets/images/bg-image.png", () => "bg-image.png");

test("renders App view", () => {
  render(<App />);
});
