// ActivitySummary.test.tsx

import React from "react";
import { render, screen, waitFor } from "@testing-library/react";
import { MyContext } from "../src/context/FMContext";
import ActivitySummary from "../src/components/ActivitySummary/ActivitySummary";
import axiosInstance from "../src/utils/interceptor";
import { mockContext } from "../__mocks__/mockContext";
import { mockActivitySummaryData } from "../__mocks__/mockAPIdata";

// Mocking the axios instance
jest.mock("../src/utils/interceptor");

function throwError() {
  throw new Error("Something went wrong");
}

describe("ActivitySummary Component", () => {
  beforeEach(() => {
    // Resetting mocks before each test
    jest.clearAllMocks();
  });

  it("renders correctly and displays loading spinner initially", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ActivitySummary setActivitySummary={jest.fn()} />
      </MyContext.Provider>
    );

    expect(screen.getByText(/Activity Summary:/i)).toBeInTheDocument();
    expect(screen.getByRole("progressbar")).toBeInTheDocument(); // Checking for spinner
  });

  it("fetches and displays activity summary data", async () => {
    (axiosInstance.post as jest.Mock).mockResolvedValueOnce({
      data: mockActivitySummaryData,
    });

    render(
      <MyContext.Provider value={mockContext}>
        <ActivitySummary setActivitySummary={jest.fn()} />
      </MyContext.Provider>
    );

    // Wait for the spinner to disappear and the table to appear
    await waitFor(() =>
      expect(screen.queryByRole("progressbar")).not.toBeInTheDocument()
    );

    // Check if table rows are rendered
    expect(screen.getByText("Activity 1")).toBeInTheDocument();
    expect(screen.getByText("10")).toBeInTheDocument();
    expect(screen.getByText("Activity 2")).toBeInTheDocument();
    expect(screen.getByText("20")).toBeInTheDocument();
  });

  it("handles errors during data fetching", async () => {
    (axiosInstance.post as jest.Mock).mockRejectedValueOnce(
      new Error("Something went wrong")
    );

    render(
      <MyContext.Provider value={mockContext}>
        <ActivitySummary setActivitySummary={jest.fn()} />
      </MyContext.Provider>
    );

    // Wait for the spinner to disappear
    await waitFor(() =>
      expect(screen.queryByRole("progressbar")).not.toBeInTheDocument()
    );

    expect(() => throwError()).toThrow(Error);
    // Optionally, you can check for an error message or log if you handle errors in your component.
  });
});
