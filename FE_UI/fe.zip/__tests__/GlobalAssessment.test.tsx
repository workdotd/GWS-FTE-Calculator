import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";

import { mockContext, mockErrorContext } from "../__mocks__/mockContext";

import GlobalAssessment from "../src/components/FinanceMgmt/GlobalAssessment";
import { MyContext } from "../src/context/FMContext";
import { ErrorContext } from "../src/context/ErrorContext";

describe("GlobalAssessment", () => {
  it("renders without crashing", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <GlobalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );
    expect(
      screen.getByText("Indicate the regions in scope under this deal")
    ).toBeInTheDocument();
  });

  it("handles checkbox changes", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <GlobalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );

    const americasCheckbox = screen.getByLabelText("AMERICAS");
    fireEvent.click(americasCheckbox);
    expect(
      mockErrorContext.FinanceManagement.Global.Region.setValue
    ).toHaveBeenCalled();
  });

  it("handles radio button changes", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <GlobalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );

    const yesRadio = screen.getByLabelText("Yes");
    fireEvent.click(yesRadio);
    expect(mockContext.SaveFM.setValue).toHaveBeenCalled();
  });

  it("displays the recommended role", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <GlobalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );

    expect(screen.getByText(/Recommended Role:/i)).toBeInTheDocument();
  });

  it("renders the dropdown for role location", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <ErrorContext.Provider value={mockErrorContext}>
          <GlobalAssessment />
        </ErrorContext.Provider>
      </MyContext.Provider>
    );

    expect(screen.getByText("Country location of Role")).toBeInTheDocument();
  });
});
