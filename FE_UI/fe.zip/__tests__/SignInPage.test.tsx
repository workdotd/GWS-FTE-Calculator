import { render, screen } from "@testing-library/react";
import { SignInPage } from "../src/views/SignInPage/SignInPage";
import bgImg from "../src/assets/images/bg-image.png";

jest.mock("../src/assets/images/bg-image.png", () => "bg-image.png");

test("renders Sign in page", () => {
  render(<SignInPage />);
  const backgroundImage = screen.getByAltText(/CBRE FTE Background/i);
  expect(backgroundImage).toBeInTheDocument();
});

test("renders SignInDialog component", () => {
  render(<SignInPage />);
  const signInDialog = screen.getByText(/CBRE/);
  expect(signInDialog).toBeInTheDocument();
});

// test("renders main element with correct class", () => {
//   render(<SignInPage />);
//   const mainElement = screen.getByRole("main");
//   console.log(mainElement.classList);
//   expect(mainElement).toHaveClass("signInFullScreen");
// });

// test("renders section element with correct class", () => {
//   render(<SignInPage />);
//   const sectionElement = screen.getByRole("region");
//   expect(sectionElement).toHaveClass("signInContainer");
// });
