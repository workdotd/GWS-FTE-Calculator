import { render, screen } from "@testing-library/react";
import { SignInButton } from "../src/views/SignInButton/SignInButton";

test("renders Sign in Button", () => {
  const label = "Sign In";
  const clickEvent = () => {
    console.log("Sign In button clicked");
  };

  render(<SignInButton label={label} clickEvent={clickEvent} />);
  const linkElement = screen.getByText(/Sign In/i);
  expect(linkElement).toBeInTheDocument();
});
