// Header.test.tsx
import React from "react";
import { render, screen } from "@testing-library/react";
import Header from "../src/components/Header/Header"; // Adjust the import path as necessary
import ClientSetUp from "../src/components/ClientSetUp/ClientSetUp";

// Mock the ClientSetUp component
jest.mock("../src/components/ClientSetUp/ClientSetUp", () => {
  return jest.fn(() => <div>Mocked Client Set Up</div>);
});

describe("Header Component", () => {
  const setDrawerMock = jest.fn();

  test("renders Header with title and ClientSetUp component", () => {
    render(<Header setDrawer={setDrawerMock} />);
    
    // Check if the title is rendered correctly
    const titleElement = screen.getByText(/Finance FTE Calculator/i);
    expect(titleElement).toBeInTheDocument();

    // Check if the mocked ClientSetUp component is rendered
    const clientSetUpElement = screen.getByText(/Mocked Client Set Up/i);
    expect(clientSetUpElement).toBeInTheDocument();
  });

  test("passes setDrawer prop to ClientSetUp", () => {
    render(<Header setDrawer={setDrawerMock} />);
    
    // Verify that setDrawer was passed correctly (if needed)
    expect(ClientSetUp).toHaveBeenCalledWith(
      expect.objectContaining({ setDrawer: setDrawerMock }),
      {}
    );
  });
  
});