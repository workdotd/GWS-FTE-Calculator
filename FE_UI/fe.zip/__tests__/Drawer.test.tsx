// Drawer.test.tsx

import React from "react";
import { render, screen } from "@testing-library/react";
import Drawer from "../src/components/Drawer/Drawer"; // Adjust the import path as necessary

describe("Drawer Component", () => {
  beforeEach(() => {
    render(<Drawer />);
  });

  it("renders the Drawer component correctly", () => {
    // Check if the main container is in the document
    const drawerSection = screen.getByText(
      /This finance FTE calculator is not a substitute for actual solutioning/i
    );
    expect(drawerSection).toBeInTheDocument();
  });

  it("displays all key advantages", () => {
    // Check for each key advantage text
    expect(
      screen.getByText(/It calculates a data-driven “base model” finance team/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /It provides an intelligent benchmark against which a solution or price can be measured and evaluated/i
      )
    ).toBeInTheDocument();
  });

  it("mentions AI and human critical thinking", () => {
    // Check for AI mention
    expect(
      screen.getByText(
        /Artificial intelligence or machine learning used in this tool does not replace valuable human critical thinking and solutioning/i
      )
    ).toBeInTheDocument();
  });
});
