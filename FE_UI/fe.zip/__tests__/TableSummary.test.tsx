import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { mockContext } from "../__mocks__/mockContext";
import Summary from "../src/components/Summary/Summary";
import { MyContext } from "../src/context/FMContext";
import { setFMAPIData } from "../src/utils/FMSave";
import axiosInstance from "../src/utils/interceptor";
import { FDAPIRegionBased } from "../src/utils/FDSave";

// Mocking utility functions
jest.mock("../src/utils/FMSave", () => ({
  setFMAPIData: jest.fn(),
}));

jest.mock("../src/utils/FDSave", () => ({
  FDAPIRegionBased: jest.fn(),
}));

jest.mock("../src/utils/interceptor", () => ({
  post: jest.fn(),
}));

describe("Summary Component", () => {
  beforeEach(() => {
    // Reset mocks before each test
    jest.clearAllMocks();
  });

  it("renders without crashing and displays titles", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <Summary />
      </MyContext.Provider>
    );

    // Check if titles are rendered
    expect(screen.getByText("Finance Management Summary")).toBeInTheDocument();
    expect(screen.getByText("Finance Delivery Summary")).toBeInTheDocument();
  });

  // it("downloads FM summary when button is clicked", async () => {
  //   const mockData = { someKey: "someValue" };
  //   const mockResponse = new Blob(["mock data"], { type: "application/csv" });

  //   (setFMAPIData as jest.Mock).mockReturnValue(mockData);
  //   (axiosInstance.post as jest.Mock).mockResolvedValue({ data: mockResponse });

  //   render(
  //     <MyContext.Provider value={mockContext}>
  //       <Summary />
  //     </MyContext.Provider>
  //   );

  //   // Click on the download button
  //   const downloadButton = screen.getByRole("button", { name: /download/i });
  //   fireEvent.click(downloadButton);

  //   // Check if API was called with correct parameters
  //   expect(setFMAPIData).toHaveBeenCalledWith(mockContext);
  //   expect(axiosInstance.post).toHaveBeenCalledWith(
  //     "finance_management/fm_summary_download",
  //     mockData,
  //     { responseType: "blob" }
  //   );

  //   // Check if the Blob URL creation and download logic works
  //   const tempLink = document.createElement("a");
  //   tempLink.href = window.URL.createObjectURL(mockResponse);
  //   tempLink.setAttribute("download", `FM_Summary_${Date.now()}.csv`);

  //   document.body.appendChild(tempLink);
  //   tempLink.click();

  //   expect(document.body.contains(tempLink)).toBe(true);

  //   document.body.removeChild(tempLink);
  // });

  // it("downloads FD summary when button is clicked", async () => {
  //   const mockData = { someKey: "someValue" };
  //   const mockResponse = new Blob(["mock data"], { type: "application/xlsx" });

  //   (FDAPIRegionBased as jest.Mock).mockReturnValue(mockData);
  //   (axiosInstance.post as jest.Mock).mockResolvedValue({ data: mockResponse });

  //   const { container } = render(
  //     <MyContext.Provider value={mockContext}>
  //       <Summary />
  //     </MyContext.Provider>
  //   );

  //   // Click on the FD download button
  //   const fdDownloadButton = container.querySelector(
  //     ".fd-summary-download-btn"
  //   );

  //   if (fdDownloadButton) {
  //     fireEvent.click(fdDownloadButton);

  //     // Check if API was called with correct parameters
  //     expect(FDAPIRegionBased).toHaveBeenCalledWith(mockContext);
  //     expect(axiosInstance.post).toHaveBeenCalledWith(
  //       "calculate_fte/activity_summary/download",
  //       mockData,
  //       { responseType: "blob" }
  //     );

  //     // Check if the Blob URL creation and download logic works
  //     const tempLink = document.createElement("a");
  //     tempLink.href = window.URL.createObjectURL(mockResponse);
  //     tempLink.setAttribute("download", `FD_Summary_${Date.now()}.xlsx`);

  //     document.body.appendChild(tempLink);
  //     tempLink.click();

  //     expect(document.body.contains(tempLink)).toBe(true);

  //     document.body.removeChild(tempLink);
  //   } else {
  //     console.log("Hi");
  //   }
  // });
});
