import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import RegionsFM from "../src/components/RegionsFM/RegionsFM"; // Adjust the import path as necessary
import { setOptions } from "../src/utils/GetValues"; // Mock this as needed
import { handleChangeFM } from "../src/utils/handleChange"; // Mock this as needed
import { mockContext, mockErrorContext } from "../__mocks__/mockContext";

// Mocking the external functions
jest.mock("../src/utils/GetValues", () => ({
  setOptions: jest.fn(),
}));

jest.mock("../src/utils/handleChange", () => ({
  handleChangeFM: jest.fn(),
}));

describe("RegionsFM Component", () => {
  beforeEach(() => {
    // Reset mocks before each test
    jest.clearAllMocks();
    // Mock return values for setOptions
    (setOptions as jest.Mock).mockReturnValue([
      [
        { label: "None", selected: true, value: "None" },
        { label: "Role 2", value: "Role2" },
      ],
      [{ label: "Growth 1", value: "Growth1" }],
      [{ label: "Contract 1", value: "Contract1" }],
      [{ label: "Performance 1", value: "Performance1" }],
    ]);
  });

  it("renders correctly with provided props", () => {
    render(
      <RegionsFM
        name="Test Region"
        context={mockContext.FinanceManagement?.RegionalAssessment?.AMERICAS}
        errorContext={mockErrorContext.FinanceManagement.AMERICAS}
        save={mockContext.SaveFM}
      />
    );

    screen.debug();

    expect(screen.getByText("Test Region")).toBeInTheDocument();
    expect(
      screen.getByText(/Finance Management Role \(required\)/i)
    ).toBeInTheDocument();
    expect(
      screen.getByLabelText(/Growth Opportunity \(required\)/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Contract Value \(required\)/i)
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Performance Risk \(required\)/i)
    ).toBeInTheDocument();
  });

  //   it("calls handleChangeFM when a role is selected", () => {
  //     const { container } = render(
  //       <RegionsFM
  //         name="Test Region"
  //         context={mockContext.FinanceManagement?.RegionalAssessment?.AMERICAS}
  //         errorContext={mockErrorContext.FinanceManagement.AMERICAS}
  //         save={mockContext.SaveFM}
  //       />
  //     );

  //     const roleDropdown = container.querySelector(".fm-region-role");

  //     if (roleDropdown) {
  //       fireEvent.change(roleDropdown, { target: { value: "Role1" } });

  //       expect(handleChangeFM).toHaveBeenCalledWith(
  //         expect.anything(), // Event object
  //         "Role1",
  //         mockContext.FinanceManagement?.RegionalAssessment?.AMERICAS?.Role
  //           ?.setValue,
  //         mockContext.SaveFM
  //       );
  //     } else {
  //       console.log("Hi");
  //     }
  //   });

  //   it("calls handleChangeFM when Growth Opportunity is selected", () => {
  //     render(
  //       <RegionsFM
  //         name="Test Region"
  //         context={mockContext}
  //         errorContext={mockErrorContext}
  //         save={mockSave}
  //       />
  //     );

  //     const growthDropdown = screen.getByLabelText(
  //       /growth opportunity \(required\)/i
  //     );

  //     fireEvent.change(growthDropdown, { target: { value: "Growth1" } });

  //     expect(handleChangeFM).toHaveBeenCalledWith(
  //       expect.anything(), // Event object
  //       "Growth1",
  //       mockContext.Growth.setValue,
  //       mockSave,
  //       mockErrorContext.Growth.setValue
  //     );
  //   });
});
