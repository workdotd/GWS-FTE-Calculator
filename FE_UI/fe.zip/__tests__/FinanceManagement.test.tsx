// FinanceManagement.test.tsx

import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { MyContext } from "../src/context/FMContext";

import { mockContext } from "../__mocks__/mockContext";
import FinanceManagement from "../src/components/FinanceMgmt/FinanceManagement"; // Adjust import path as necessary

describe("FinanceManagement Component", () => {
  const scrollableRefMock = React.createRef<HTMLDivElement>();

  beforeEach(() => {
    jest.clearAllMocks(); // Clear any previous mock calls
  });

  it("renders correctly and displays section description", () => {
    render(
      <MyContext.Provider value={mockContext}>
        <FinanceManagement scrollableRef={scrollableRefMock} />
      </MyContext.Provider>
    );

    // Check if the section description is rendered
    expect(
      screen.getByText(
        /Is there a clear client requirement to hire a specific finance leader role from at least 1 region?/i
      )
    ).toBeInTheDocument();

    // Check if accordion titles are rendered
    expect(screen.getByText("Regional Assessment")).toBeInTheDocument();
    expect(screen.getByText("Global Assessment")).toBeInTheDocument();
  });
});
